# Plugins

Un plugin ajoute votre propre code JavaScript à Gowam. Avec un plugin, vous pouvez vérifier un champ, modifier un formulaire, ajouter une entrée de menu, refuser un enregistrement, donner le prix d'un article ou ajouter une nouvelle page complète. Vous ne modifiez pas Gowam lui-même.

## Créer un plugin

1. Ouvrez **Paramètres > Plugins** et ajoutez un plugin. Donnez-lui un code (par exemple `item_rules`), une description, un auteur et une version. Activez **Actif** et enregistrez.
2. Ouvrez à nouveau le plugin et cliquez sur **Code source**. Ajoutez une source : donnez-lui un nom et écrivez votre code JavaScript. Un plugin peut avoir plusieurs sources. Gowam les réunit dans un seul fichier.
3. Revenez au plugin et écrivez les lignes dans **Code JS d’enregistrement des événements**. Chaque ligne indique à Gowam quand appeler une de vos fonctions (voir [Le champ Enregistrement des événements](#le-champ-enregistrement-des-evenements)).
4. Cliquez sur **Enregistrer** dans le plugin. Gowam vérifie le code et le charge. Votre code s'exécute à partir de maintenant.

**Remarque :** Gowam charge le code quand vous enregistrez le plugin, pas quand vous enregistrez une source. Après avoir modifié une source, ouvrez le plugin et cliquez à nouveau sur **Enregistrer**. **Contrôler** vous dit quand une source a changé après le chargement (voir [Contrôler un plugin](#controler-un-plugin)).

## Les types de plugins

| Type | Ligne d'enregistrement | Gowam appelle votre fonction |
|---|---|---|
| [Valider](validate.md) | `registerValidate` | quand l'utilisateur modifie un champ ou clique sur un bouton |
| [Après construction du formulaire](after-build.md) | `registerAfterBuildUI` | quand un formulaire est prêt, juste avant que Gowam l'affiche |
| [Élément de menu](menu-item.md) | `registerBuildMenu` | quand Gowam ouvre un menu |
| [Peut enregistrer](can-save.md) | `registerCanSave` | quand l'utilisateur enregistre, avant que Gowam lise le formulaire |
| [Avant l'enregistrement](before-save.md) | `registerBeforeSave` | quand l'enregistrement est prêt, juste avant que Gowam l'écrive |
| [Fonction](function.md) | `registerFunction` | quand Gowam a besoin d'une valeur qu'un plugin peut donner |
| [Liste/Formulaire](list-form.md) | `registerListForm` | pour afficher votre propre page avec une liste et un formulaire |

Chaque ligne d'enregistrement accepte aussi `active: false`, pour désactiver la ligne sans la supprimer, et `description: "..."`, pour vos propres notes.

Gowam garde une seule fonction par événement. Si deux lignes enregistrent la même page et le même champ (ou la même page et le même type, ou le même menu), Gowam utilise la dernière.

## Le champ Enregistrement des événements

Le champ **Code JS d’enregistrement des événements** du plugin indique à Gowam quelles fonctions appeler, et quand. Écrivez une ligne pour chaque événement :

```js
registerValidate({page: "Item", field: "@itemId", function: "itemCheckCode", before: true});
registerCanSave({page: "Item", function: "itemNeedComment"});
registerFunction({function: "ItemPriceLDAO_getPrice"});
```

- Chaque ligne appelle une des fonctions d'enregistrement du tableau ci-dessus, avec les paramètres entre `{` et `}`. La page de chaque type donne ses paramètres.
- Mettez les textes entre guillemets : `function: "itemCheckCode"`. `true`, `false` et les nombres n'ont pas de guillemets.
- `function` est le nom d'une fonction de votre code source. Quand vous enregistrez le plugin, Gowam ouvre le contrôle si cette fonction n'est pas dans le code chargé (voir [Contrôler un plugin](#controler-un-plugin)). Quand le nom est faux, Gowam fait comme quand votre fonction génère une erreur (voir [Erreurs](#erreurs)).
- Écrivez seulement des lignes d'enregistrement ici. Vos fonctions vont dans le **Code source**.

**Ajouter un événement** ajoute une ligne avec tous les paramètres d'un type. Remplacez `TableName`, `fieldName` et `methodName` par vos noms.

**Voir Plugin JSON (debug uniquement)** montre les événements tels que Gowam va les enregistrer, ou l'erreur.

Quand vous cliquez sur **Enregistrer**, Gowam vérifie chaque ligne. Si une ligne est fausse, Gowam n'enregistre pas et affiche l'erreur. L'erreur commence par la fonction d'enregistrement et son numéro : `registerValidate (call 2)` est la deuxième ligne `registerValidate`.

| L'erreur dit | Faites ceci |
|---|---|
| `missing required parameter 'field'` | ajoutez le paramètre |
| `unknown parameter 'fonction'` | corrigez le nom du paramètre. L'erreur donne les noms corrects |
| `invalid value for parameter 'active'` | enlevez les guillemets : `active: false` |
| `parameter 'function' cannot be empty` | tapez le nom |
| `invalid type 'Preview'` | `type` est `"form"`, `"list"`, `"preview"` ou `"menu"` |
| `an event with the same parameters is already registered` | supprimez une des deux lignes |
| `JavaScript Error` et le nom de votre fonction | mettez le nom entre guillemets |
| `JavaScript Error` et le nom d'une fonction d'enregistrement | écrivez la fonction d'enregistrement exactement comme dans le tableau ci-dessus, avec les mêmes majuscules |
| `JavaScript Error` et un autre texte | corrigez le JavaScript, par exemple ajoutez un `)` ou un `}` qui manque |

Gowam enregistre les événements, pas votre texte. Quand vous ouvrez à nouveau le plugin, Gowam réécrit les lignes à partir des événements : il ajoute les paramètres qui ont une valeur par défaut, comme `type: "form"` et `active: true`, et enlève les commentaires et les lignes vides. Les trois lignes ci-dessus deviennent :

```js
registerValidate({page: "Item", type: "form", field: "@itemId", function: "itemCheckCode", before: true, active: true});
registerCanSave({page: "Item", type: "form", function: "itemNeedComment", active: true});
registerFunction({function: "ItemPriceLDAO_getPrice", active: true});
```

Pour désactiver une ligne sans la supprimer, changez `active: true` en `active: false` et enregistrez le plugin.

## Trouver les noms des pages et des champs

Activez le **Mode développeur** en haut de la liste **Plugins**. Ensuite :

- Chaque barre de titre affiche une icône de développeur. Placez la souris sur cette icône pour voir le nom de la page, ou le nom du menu sur une page de menu. Utilisez ce nom pour `page:` et `menu:`. Cliquez sur l'icône pour ouvrir la liste **Plugins**.
- Placez la souris sur un champ pour voir son nom de champ. Utilisez ce nom pour `field:` et dans votre code.

Les noms de champs gardent leur premier caractère : `@itemId`, `€purchaseQty`, `!stockMethod`, `-€salePrice`. Tapez-les exactement comme Gowam les affiche.

Quelques noms de pages : `Item`, `ThirdParty`, `Doc`, `DocRow`, `Journal`.

La liste, l'aperçu et le formulaire d'une table utilisent le même nom de page. Pour les articles, les trois sont `Item`. Dans [Après construction du formulaire](after-build.md), `type` indique lequel vous modifiez.

## Les contrôles

Un formulaire est une liste de contrôles. Gowam donne cette liste à votre fonction. Chaque contrôle est un objet :

```js
{
  fieldName: "@itemId",
  controlType: "textField",
  label: "Code",
  value: "COFFEE",
  isVisible: true,
  isReadOnly: false
}
```

La valeur d'un champ texte est un texte, aussi pour les nombres (`"12.50"`). La valeur d'un interrupteur ou d'une case à cocher est `true` ou `false`. La valeur d'une liste déroulante qui pointe vers un enregistrement, comme `@unit`, est l'id de cet enregistrement (`0` quand elle est vide).

Votre fonction reçoit une copie des contrôles. Pour modifier le formulaire, retournez les contrôles ([Après construction du formulaire](after-build.md)) ou retournez `Cmd.updatedMaps` avec les contrôles ([Valider](validate.md)).

## Les outils dans votre code

Gowam charge ces objets avant votre code. Vous pouvez les utiliser partout.

| Objet | Pour |
|---|---|
| `Field` | lire et modifier des contrôles : `Field.getControl(controls, "@itemId")`, `Field.stringGet`, `Field.integerGet`, `Field.floatGet`, `Field.booleanGet`, `Field.lookupGet`, `Field.stringSet`, `Field.floatSet`, `Field.setVisible`, `Field.setReadOnly`, `Field.setLabel`, `Field.getControlIndex`, `Field.removeControl` |
| `GenControl` | créer de nouveaux contrôles : `GenControl.textField({...})`, `GenControl.text`, `GenControl.separator`, `GenControl.switchBox`, `GenControl.dropdown`, `GenControl.buttonFunction` |
| `LDAO` | lire et écrire des enregistrements : `LDAO.getSync("Item", id)`, `LDAO.getByKeySync("Item", "COFFEE")`, `LDAO.getListFilterSync("Item", {filters: {...}, count: 20})`, `LDAO.countAllSync("Item")`, `await LDAO.save("Item", item)` |
| `Cmd` | les commandes que vous pouvez retourner : `Cmd.updatedMaps`, `Cmd.updateControls`, `Cmd.refresh`, `Cmd.closeForm`, `Cmd.setFocus("@comment")` |
| `pluginPrint` | `pluginPrint("text")` écrit une ligne dans le fichier log de Gowam (**Outils > Log > Fichiers LOG**) |
| `httpRequest` | `await httpRequest("POST", url, body, headers)` appelle un service web et donne `{statusCode, body}`. `statusCode` vaut `-1` quand le service ne répond pas |
| `getDocRowsByItemId` | `getDocRowsByItemId("COFFEE")` donne les lignes de documents d'un article |
| `getItemIdById` | `getItemIdById(12)` donne le code de l'article qui a l'id `12` |
| `navigateToForm` | `navigateToForm(objectId, "Item", "", 0, "Title", "", null, null, false)` ouvre un formulaire |
| `navigateToList` | `navigateToList("Item", "", 0, false, false, null, null)` ouvre une liste |
| `navigateToMenu` | `navigateToMenu("Settings", "main_settings")` ouvre un menu |

Une fonction peut être `async` et utiliser `await`. Gowam attend le résultat.

## Enregistrements

`LDAO` donne les enregistrements sous forme d'objets. `_id` est l'id de l'enregistrement sur cet appareil. Gardez-le : quand vous enregistrez un objet qui a un `_id`, Gowam modifie cet enregistrement et n'en ajoute pas un nouveau.

Gowam omet les champs qui sont vides ou à `0`. Lisez-les avec une valeur par défaut : `item.salePrice || 0`.

Les noms des champs dépendent de la base de données :

| Base de données Gowam | Base de données logistique |
|---|---|
| `itemId` | `artid` |
| `salePrice` | `saleprice` |
| `supplierReference` | `buyartid` |

Les filtres de `LDAO.getListFilterSync` utilisent toujours les noms de la base de données Gowam. Si votre plugin doit fonctionner avec les deux bases de données, utilisez une petite fonction qui donne le bon nom :

```js
function itemFieldName(record, gowamName, logisticsName) {
  if (record.uuid === undefined) {
    return gowamName;
  }

  return logisticsName;
}
```

Ensuite, lisez et écrivez avec `item[itemFieldName(item, "salePrice", "saleprice")]`.

## Erreurs

- **Valider, Peut enregistrer et Avant l'enregistrement** : quand votre fonction lève une erreur, Gowam affiche le texte de l'erreur à l'utilisateur. Avec Peut enregistrer et Avant l'enregistrement, Gowam n'enregistre pas.
- **Après construction du formulaire, Élément de menu et Fonction** : quand votre fonction lève une erreur ou retourne une valeur incorrecte, Gowam continue comme s'il n'y avait pas de plugin.
- **Liste/Formulaire** : une méthode qui lève une erreur affiche le texte de l'erreur, ou rien.

Utilisez `pluginPrint` pour voir ce que fait votre code. **Contrôler** affiche les derniers messages (voir [Contrôler un plugin](#controler-un-plugin)).

## Contrôler un plugin

Cliquez sur **Contrôler** dans le plugin pour voir si Gowam l'exécute vraiment. Le contrôle affiche :

- **Plugin** : quand Gowam a chargé le plugin, ou pourquoi Gowam ne l'exécute pas : le plugin n'est pas actif, le code contient une erreur, ou une source a changé après le chargement et vous devez enregistrer à nouveau le plugin.
- **Enregistrement des événements** : une carte pour chaque ligne. Une carte verte est une ligne que Gowam appelle. Une carte grise est une ligne désactivée. Une carte orange ou rouge dit ce qui ne va pas, par exemple :
    - la fonction n'est pas dans le code chargé : un nom faux, ou une source qui n'est pas active ;
    - la page n'existe pas, ou la page n'appelle jamais cet événement : Peut enregistrer et Avant l'enregistrement fonctionnent seulement sur `Item` et `Doc`, Après construction du formulaire seulement avec les types `form` et `preview` ;
    - une autre ligne ou un autre plugin utilise le même événement, donc Gowam n'en appelle qu'un seul ;
    - Gowam n'a pas de menu avec ce nom, ou n'appelle jamais une fonction avec ce nom. Gowam n'appelle jamais Élément de menu pour le menu latéral `main` ;
    - une ligne sur la page `DocRow` s'exécute seulement dans le formulaire de ligne qui s'ouvre seul, depuis la feuille d'un document. Pour une ligne dans le document, le contrôle donne la ligne `Doc` à ajouter ;
    - après que vous avez ouvert la page une fois : la page n'a jamais affiché le champ (un nom de champ faux), ou le champ est d'un type qui n'appelle jamais Valider, par exemple labels ou markdown. Avant que vous ouvriez la page, la carte vous demande de l'ouvrir.
- **Appels depuis le chargement** : une carte pour chaque fonction que Gowam peut appeler, avec la page et le champ. Elle montre le nombre d'appels, l'heure du dernier appel et la dernière réponse de votre fonction, ou que Gowam ne l'a pas encore appelée.
- **Derniers messages des plugins** : les derniers textes de `pluginPrint` et les erreurs de tous les plugins, les plus récents en premier.

Gowam compte les appels depuis le dernier chargement. Quand vous enregistrez un plugin, Gowam charge à nouveau tous les plugins et les compteurs repartent de 0. Utilisez la page qui appelle votre fonction, puis cliquez sur **Contrôler à nouveau**.

Quand vous enregistrez un plugin et qu'une ligne ne fonctionnera pas, Gowam ouvre le contrôle.

Quand le contrôle trouve un problème, cliquez sur **Corriger avec l'IA**. L'Agent IA du plugin s'ouvre, reçoit la liste des problèmes et corrige les lignes d'enregistrement. Rien n'est encore enregistré : le contrôle montre toujours les anciens problèmes. Cliquez sur **Enregistrer et contrôler** sous la discussion. Gowam enregistre le plugin, le charge et le contrôle à nouveau.

Quand le champ Enregistrement des événements a des modifications non enregistrées, le contrôle montre aussi **Enregistrer et contrôler**.

## Écrire le code dans VS Code

Sous Windows, macOS et Linux, la page du code source a les boutons **Ouvrir dans VS Code** et **Importer depuis VS Code**. Gowam écrit vos sources dans un dossier, avec le dossier `gowam_api` qui décrit `Field`, `GenControl`, `LDAO` et `Cmd`, pour que VS Code puisse compléter leurs noms. Quand vous avez terminé, enregistrez dans VS Code et cliquez sur **Importer depuis VS Code**. Gowam vérifie le code et le charge.

## Bonnes pratiques

- Tous les plugins partagent un seul espace JavaScript. Commencez les noms de vos fonctions par un mot court propre à votre plugin (`itemCheckCode`), pour que deux plugins n'utilisent jamais le même nom.
- En dehors d'une fonction, utilisez `function` et `var`, pas `const` ou `let`. Si deux plugins utilisent le même nom `const`, le code du deuxième plugin ne se charge pas.
- Testez avec le **Mode développeur** activé, et regardez le fichier log.
