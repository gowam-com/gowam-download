# List/Form

A List/Form plugin adds a complete page to Gowam: a list of cards and a form, like the pages of Gowam. Gowam calls the methods of an object that your code defines.

## Register

```js
registerListForm({page: "ItemsWithoutReference", class: "ItemsWithoutReference", listSearch: true, listPreview: false, listAdd: false, listForm: true, listMaxWidth: 1200, formDelete: false, formSave: true, formMaxWidth: 800, listCardsCount: 20});
```

| Parameter | |
|---|---|
| `page` | the name of your page. Use a name that Gowam does not use |
| `class` | the name of the object in your code |
| `listSearch` | show a search box above the list |
| `listPreview` | show a preview when the user clicks a card. With `false`, the click opens the form |
| `listAdd` | show the button that adds a record |
| `listForm` | the list has a form |
| `listMaxWidth`, `formMaxWidth` | the maximum width of the list and of the form, in pixels |
| `formDelete`, `formSave` | show the delete and save buttons in the title bar of the form |
| `listCardsCount` | the number of cards that Gowam asks for each time |
| `backgroundColors` | the colors of the background, for example `["#ffffff", "#f5f5f5", "#e3f2fd"]` |
| `active` | `false` switches the line off |

To open the page, add an entry to a menu with a [Menu Item](menu-item.md#example-4-open-your-own-page) plugin: `type: "list"` and `childTableName` = the name of your page.

## The methods

Define all the methods, also the ones that you do not need. A method can be `async`.

| Method | Return |
|---|---|
| `genListGetTitle(parentId, parentTableName, args)` | the title of the list |
| `genListFirstControls(parentId, parentTableName, args)` | the controls above the list, `[]` for none |
| `genListGetCards(filter, offset, count, parentId, parentTableName, controls, args)` | the cards: `count` cards from the card number `offset`. `filter` is the text of the search box. `LDAO.getListFilterSync` searches this text in the fields of `listSearchProperties` |
| `genListGetCard(objectId, parentTableName, parentId, controls, args)` | the card of one record |
| `genListNavigateBack(controls)` | `""` |
| `genPreviewGetControls(objectId, isSelect, args)` | the controls of the preview, `[]` for none |
| `genGetDropdownDisplay(id, args)` | the text that a dropdown shows for this record |
| `genGetSearchCode(id, args)` | the code of the record |
| `genFormGetTitle(objectId, parentId, parentTableName, subForm, args)` | the title of the form |
| `genFormGetControls(objectId, parentId, parentTableName, subForm, source, searchControls, args)` | the controls of the form |
| `genFormSave(controls, objectId, parentId, parentTableName, fromSaveButton, subForm, args)` | the id of the saved record, `0` if it was not saved |
| `genFormDelete(objectId, args)` | the id of the deleted record, `0` if it was not deleted |
| `genFormNavigateBack(controls, objectId)` | `""` |

Return lists and objects, not JSON texts. `args` is a JSON text, or `""`.

A card is an object with the id of the record and columns of controls:

```js
{
  objectId: 12,
  columns: [
    {width: 100, widthType: "variablePercentage", controls: [GenControl.text({fieldName: "title", label: "COFFEE"})]}
  ]
}
```

`widthType` is `"variablePercentage"` (the width is a percentage) or `"fixedPixels"` (the width is in pixels).

## Example 1: the items without a supplier reference

The page shows the items that have no supplier reference. A click on an item opens a form where the user types the reference.

```js
registerListForm({page: "ItemsWithoutReference", class: "ItemsWithoutReference", listSearch: true, listPreview: false, listAdd: false, listForm: true, listMaxWidth: 1200, formDelete: false, formSave: true, formMaxWidth: 800, listCardsCount: 20});
```

The function `itemFieldName` gives the name of a field in a Gowam database or in a logistics database (see [Records](index.md#records)).

```js
function itemFieldName(record, gowamName, logisticsName) {
  if (record.uuid === undefined) {
    return gowamName;
  }

  return logisticsName;
}

function itemTitle(item) {
  var code = item[itemFieldName(item, "itemId", "artid")];
  var names = item.names || [];

  return code + " " + (names[0] || "");
}

function itemCard(item) {
  return {
    objectId: item._id,
    columns: [
      {
        width: 100,
        widthType: "variablePercentage",
        controls: [
          GenControl.text({fieldName: "title", label: itemTitle(item), textStyle: {fontWeight: "bold", fontSize: 16}})
        ]
      }
    ]
  };
}

var ItemsWithoutReference = {
  genListGetTitle: function (parentId, parentTableName, args) {
    return "Items without a supplier reference";
  },

  genListFirstControls: function (parentId, parentTableName, args) {
    return [];
  },

  genListGetCards: function (filter, offset, count, parentId, parentTableName, controls, args) {
    var items = LDAO.getListFilterSync("Item", {
      search: filter,
      listSearchProperties: ["itemId", "names"],
      filters: {supplierReference: ""},
      offset: offset,
      count: count
    });

    return items.map(itemCard);
  },

  genListGetCard: function (objectId, parentTableName, parentId, controls, args) {
    return itemCard(LDAO.getSync("Item", objectId));
  },

  genListNavigateBack: function (controls) {
    return "";
  },

  genPreviewGetControls: function (objectId, isSelect, args) {
    return [];
  },

  genGetDropdownDisplay: function (id, args) {
    return itemTitle(LDAO.getSync("Item", id));
  },

  genGetSearchCode: function (id, args) {
    var item = LDAO.getSync("Item", id);

    return item[itemFieldName(item, "itemId", "artid")];
  },

  genFormGetTitle: function (objectId, parentId, parentTableName, subForm, args) {
    return "Supplier reference";
  },

  genFormGetControls: function (objectId, parentId, parentTableName, subForm, source, searchControls, args) {
    var item = LDAO.getSync("Item", objectId);

    return [
      GenControl.text({fieldName: "itemTitleText", label: itemTitle(item), textStyle: {fontWeight: "bold", fontSize: 16}}),
      Field.stringControl({fieldName: "itemReference", label: "Supplier reference", text: "", maxLength: 30}),
      GenControl.buttonSave()
    ];
  },

  genFormSave: async function (controls, objectId, parentId, parentTableName, fromSaveButton, subForm, args) {
    var reference = Field.stringGet(controls, "itemReference");

    if (reference === "") {
      return 0;
    }

    var item = LDAO.getSync("Item", objectId);

    item[itemFieldName(item, "supplierReference", "buyartid")] = reference;
    await LDAO.save("Item", item);

    return objectId;
  },

  genFormDelete: function (objectId, args) {
    return 0;
  },

  genFormNavigateBack: function (controls, objectId) {
    return "";
  }
};
```

## Example 2: the sales of an item

The page shows the sales history of one item: its document rows in a table, with the margin. It has no list: the **Statistics** button of [After Build](after-build.md#example-6-a-statistics-button-in-the-preview) opens its form with the id of the item. The functions `itemFieldName` and `itemTitle` of example 1 must be in your code too.

```js
registerListForm({page: "ItemPluginStatistics", class: "ItemPluginStatistics", listSearch: false, listPreview: false, listAdd: false, listForm: true, formDelete: false, formSave: false});
```

```js
function itemSalesRow(row) {
  var amount = row.amount || 0;
  var costAmount = row[itemFieldName(row, "costAmount", "costamount")] || 0;

  return [
    row[itemFieldName(row, "journalId", "jnl")] || "",
    String(row.number || ""),
    String(row.date || "").substring(0, 10),
    row.qty || 0,
    row[itemFieldName(row, "unitPrice", "unitprice")] || 0,
    row[itemFieldName(row, "discountPc", "discount")] || 0,
    amount,
    costAmount,
    amount - costAmount
  ];
}

var ItemPluginStatistics = {
  genListGetTitle: function (parentId, parentTableName, args) {
    return "Sales history";
  },

  genListFirstControls: function (parentId, parentTableName, args) {
    return [];
  },

  genListGetCards: function (filter, offset, count, parentId, parentTableName, controls, args) {
    return [];
  },

  genListGetCard: function (objectId, parentTableName, parentId, controls, args) {
    return {};
  },

  genListNavigateBack: function (controls) {
    return "";
  },

  genPreviewGetControls: function (objectId, isSelect, args) {
    return [];
  },

  genGetDropdownDisplay: function (id, args) {
    return "";
  },

  genGetSearchCode: function (id, args) {
    return "";
  },

  genFormGetTitle: function (objectId, parentId, parentTableName, subForm, args) {
    return "Sales history";
  },

  genFormGetControls: function (objectId, parentId, parentTableName, subForm, source, searchControls, args) {
    var item = LDAO.getSync("Item", objectId);
    var rows = getDocRowsByItemId(item[itemFieldName(item, "itemId", "artid")]);
    var controls = [GenControl.text({fieldName: "itemSalesTitle", label: itemTitle(item), textStyle: {fontWeight: "bold", fontSize: 16}})];

    if (rows.length === 0) {
      controls.push(GenControl.text({fieldName: "itemSalesNone", label: "No history found for this item."}));

      return controls;
    }

    controls.push(GenControl.text({fieldName: "itemSalesCount", label: "History (" + rows.length + " records)"}));
    controls.push(GenControl.gowamSheetViewer({
      fieldName: "itemSalesSheet",
      gowamSheet: {
        titles: ["Journal", "Number", "Date", "Quantity", "Unit price", "Discount", "Amount", "Cost amount", "Margin"],
        types: ["String", "String", "String", "double", "double", "double", "double", "double", "double"],
        data: rows.map(itemSalesRow)
      }
    }));

    return controls;
  },

  genFormSave: function (controls, objectId, parentId, parentTableName, fromSaveButton, subForm, args) {
    return 0;
  },

  genFormDelete: function (objectId, args) {
    return 0;
  },

  genFormNavigateBack: function (controls, objectId) {
    return "";
  }
};
```
