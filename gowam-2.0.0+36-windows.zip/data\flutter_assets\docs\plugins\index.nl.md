# Plugins

Een plugin voegt uw eigen JavaScript-code toe aan Gowam. Met een plugin kunt u een veld controleren, een formulier wijzigen, een menu-item toevoegen, het opslaan weigeren, de prijs van een artikel geven of een volledig nieuwe pagina toevoegen. U wijzigt Gowam zelf niet.

## Een plugin maken

1. Open **Instellingen > Plugins** en voeg een plugin toe. Geef de plugin een code (bijvoorbeeld `item_rules`), een omschrijving, een auteur en een versie. Zet **Actief** aan en sla op.
2. Open de plugin opnieuw en klik op **Broncode**. Voeg een bron toe: geef de bron een naam en schrijf uw JavaScript-code. Een plugin kan meerdere bronnen hebben. Gowam voegt ze samen in één bestand.
3. Ga terug naar de plugin en schrijf de regels van **JS-code voor het registreren van gebeurtenissen**. Elke regel vertelt Gowam wanneer Gowam een van uw functies moet aanroepen (zie [Het veld Gebeurtenissen registreren](#het-veld-gebeurtenissen-registreren)).
4. Klik op **Opslaan** in de plugin. Gowam controleert de code en laadt die. Uw code werkt vanaf nu.

**Opmerking:** Gowam laadt de code wanneer u de plugin opslaat, niet wanneer u een bron opslaat. Open de plugin nadat u een bron hebt gewijzigd en klik opnieuw op **Opslaan**. **Controleren** toont wanneer een bron na het laden is gewijzigd (zie [Een plugin controleren](#een-plugin-controleren)).

## De soorten plugins

| Soort | Registratieregel | Gowam roept uw functie aan |
|---|---|---|
| [Valideren](validate.md) | `registerValidate` | wanneer de gebruiker een veld wijzigt of op een knop klikt |
| [Na formulier opbouwen](after-build.md) | `registerAfterBuildUI` | wanneer een formulier klaar is, net voordat Gowam het toont |
| [Menu-item](menu-item.md) | `registerBuildMenu` | wanneer Gowam een menu opent |
| [Kan opslaan](can-save.md) | `registerCanSave` | wanneer de gebruiker opslaat, voordat Gowam het formulier leest |
| [Voor het opslaan](before-save.md) | `registerBeforeSave` | wanneer het record klaar is, net voordat Gowam het schrijft |
| [Functie](function.md) | `registerFunction` | wanneer Gowam een waarde nodig heeft die een plugin kan geven |
| [Lijst/Formulier](list-form.md) | `registerListForm` | om uw eigen pagina met een lijst en een formulier te tonen |

Elke registratieregel accepteert ook `active: false`, om de regel uit te zetten zonder hem te verwijderen, en `description: "..."`, voor uw eigen notities.

Gowam bewaart één functie per gebeurtenis. Als twee regels dezelfde pagina en hetzelfde veld registreren (of dezelfde pagina en hetzelfde type, of hetzelfde menu), gebruikt Gowam de laatste regel.

## Het veld Gebeurtenissen registreren

Het veld **JS-code voor het registreren van gebeurtenissen** van de plugin vertelt Gowam welke van uw functies Gowam moet aanroepen, en wanneer. Schrijf een regel voor elke gebeurtenis:

```js
registerValidate({page: "Item", field: "@itemId", function: "itemCheckCode", before: true});
registerCanSave({page: "Item", function: "itemNeedComment"});
registerFunction({function: "ItemPriceLDAO_getPrice"});
```

- Elke regel roept een van de registratiefuncties uit de tabel hierboven aan, met de parameters tussen `{` en `}`. De pagina van elke soort geeft de parameters.
- Zet teksten tussen aanhalingstekens: `function: "itemCheckCode"`. `true`, `false` en getallen hebben geen aanhalingstekens.
- `function` is de naam van een functie in uw broncode. Wanneer u de plugin opslaat, opent Gowam de controle als deze functie niet in de geladen code staat (zie [Een plugin controleren](#een-plugin-controleren)). Als de naam fout is, doet Gowam hetzelfde als wanneer uw functie een fout geeft (zie [Fouten](#fouten)).
- Schrijf hier alleen registratieregels. Uw functies horen in de **Broncode**.

**Een gebeurtenis toevoegen** voegt een regel toe met alle parameters van een soort. Vervang `TableName`, `fieldName` en `methodName` door uw namen.

**Bekijk Plugin JSON (alleen debug)** toont de gebeurtenissen zoals Gowam ze zal opslaan, of de fout.

Wanneer u op **Opslaan** klikt, controleert Gowam elke regel. Als een regel fout is, slaat Gowam niet op en toont Gowam de fout. De fout begint met de registratiefunctie en het nummer: `registerValidate (call 2)` is de tweede regel `registerValidate`.

| De fout zegt | Doe dit |
|---|---|
| `missing required parameter 'field'` | voeg de parameter toe |
| `unknown parameter 'fonction'` | verbeter de naam van de parameter. De fout geeft de juiste namen |
| `invalid value for parameter 'active'` | verwijder de aanhalingstekens: `active: false` |
| `parameter 'function' cannot be empty` | typ de naam |
| `invalid type 'Preview'` | `type` is `"form"`, `"list"`, `"preview"` of `"menu"` |
| `an event with the same parameters is already registered` | verwijder een van de twee regels |
| `JavaScript Error` en de naam van uw functie | zet de naam tussen aanhalingstekens |
| `JavaScript Error` en de naam van een registratiefunctie | schrijf de registratiefunctie precies zoals in de tabel hierboven, met dezelfde hoofdletters |
| `JavaScript Error` en een andere tekst | verbeter de JavaScript, voeg bijvoorbeeld een ontbrekende `)` of `}` toe |

Gowam slaat de gebeurtenissen op, niet uw tekst. Wanneer u de plugin opnieuw opent, schrijft Gowam de regels opnieuw op basis van de gebeurtenissen: Gowam voegt de parameters toe die een standaardwaarde hebben, zoals `type: "form"` en `active: true`, en verwijdert de commentaarregels en de lege regels. De drie regels hierboven worden:

```js
registerValidate({page: "Item", type: "form", field: "@itemId", function: "itemCheckCode", before: true, active: true});
registerCanSave({page: "Item", type: "form", function: "itemNeedComment", active: true});
registerFunction({function: "ItemPriceLDAO_getPrice", active: true});
```

Om een regel uit te zetten zonder hem te verwijderen, verander `active: true` in `active: false` en sla de plugin op.

## De namen van de pagina's en velden vinden

Zet **Ontwikkelaarsmodus** aan bovenaan de lijst **Plugins**. Dan:

- Elke titelbalk toont een ontwikkelaarspictogram. Houd de muis op dit pictogram om de naam van de pagina te zien, of de naam van het menu op een menupagina. Gebruik deze naam voor `page:` en `menu:`. Klik op het pictogram om de lijst **Plugins** te openen.
- Houd de muis op een veld om de veldnaam te zien. Gebruik deze naam voor `field:` en in uw code.

Veldnamen behouden hun eerste teken: `@itemId`, `€purchaseQty`, `!stockMethod`, `-€salePrice`. Typ ze precies zoals Gowam ze toont.

Enkele paginanamen: `Item`, `ThirdParty`, `Doc`, `DocRow`, `Journal`.

De lijst, de voorbeeldweergave en het formulier van een tabel gebruiken dezelfde paginanaam. Voor de artikelen zijn alle drie `Item`. In [Na formulier opbouwen](after-build.md) zegt `type` welke u wijzigt.

## De controls

Een formulier is een lijst van controls. Gowam geeft deze lijst aan uw functie. Elke control is een object:

```js
{
  fieldName: "@itemId",
  controlType: "textField",
  label: "Code",
  value: "COFFEE",
  isVisible: true,
  isReadOnly: false
}
```

De waarde van een tekstveld is een tekst, ook voor getallen (`"12.50"`). De waarde van een schakelaar of een selectievakje is `true` of `false`. De waarde van een keuzelijst die naar een record verwijst, zoals `@unit`, is de id van dat record (`0` als de keuzelijst leeg is).

Uw functie krijgt een kopie van de controls. Om het formulier te wijzigen, geeft u de controls terug ([Na formulier opbouwen](after-build.md)) of geeft u `Cmd.updatedMaps` met de controls terug ([Valideren](validate.md)).

## De hulpmiddelen in uw code

Gowam laadt deze objecten vóór uw code. U kunt ze overal gebruiken.

| Object | Voor |
|---|---|
| `Field` | controls lezen en wijzigen: `Field.getControl(controls, "@itemId")`, `Field.stringGet`, `Field.integerGet`, `Field.floatGet`, `Field.booleanGet`, `Field.lookupGet`, `Field.stringSet`, `Field.floatSet`, `Field.setVisible`, `Field.setReadOnly`, `Field.setLabel`, `Field.getControlIndex`, `Field.removeControl` |
| `GenControl` | nieuwe controls maken: `GenControl.textField({...})`, `GenControl.text`, `GenControl.separator`, `GenControl.switchBox`, `GenControl.dropdown`, `GenControl.buttonFunction` |
| `LDAO` | records lezen en schrijven: `LDAO.getSync("Item", id)`, `LDAO.getByKeySync("Item", "COFFEE")`, `LDAO.getListFilterSync("Item", {filters: {...}, count: 20})`, `LDAO.countAllSync("Item")`, `await LDAO.save("Item", item)` |
| `Cmd` | opdrachten die u kunt teruggeven: `Cmd.updatedMaps`, `Cmd.updateControls`, `Cmd.refresh`, `Cmd.closeForm`, `Cmd.setFocus("@comment")` |
| `pluginPrint` | `pluginPrint("text")` schrijft een regel in het logbestand van Gowam (**Hulpmiddelen > Log > Logbestanden**) |
| `httpRequest` | `await httpRequest("POST", url, body, headers)` roept een webservice aan en geeft `{statusCode, body}`. `statusCode` is `-1` als de service niet antwoordt |
| `getDocRowsByItemId` | `getDocRowsByItemId("COFFEE")` geeft de documentregels van een artikel |
| `getItemIdById` | `getItemIdById(12)` geeft de code van het artikel met het id `12` |
| `navigateToForm` | `navigateToForm(objectId, "Item", "", 0, "Title", "", null, null, false)` opent een formulier |
| `navigateToList` | `navigateToList("Item", "", 0, false, false, null, null)` opent een lijst |
| `navigateToMenu` | `navigateToMenu("Settings", "main_settings")` opent een menu |

Een functie kan `async` zijn en `await` gebruiken. Gowam wacht op het resultaat.

## Records

`LDAO` geeft records als objecten. `_id` is de id van het record op dit apparaat. Bewaar deze id: wanneer u een object met een `_id` opslaat, wijzigt Gowam dit record en voegt Gowam geen nieuw record toe.

Gowam laat de velden weg die leeg of `0` zijn. Lees ze met een standaardwaarde: `item.salePrice || 0`.

De namen van de velden hangen af van de database:

| Gowam-database | Logistieke database |
|---|---|
| `itemId` | `artid` |
| `salePrice` | `saleprice` |
| `supplierReference` | `buyartid` |

De filters van `LDAO.getListFilterSync` gebruiken altijd de Gowam-namen. Als uw plugin met beide databases moet werken, gebruik dan een kleine functie die de juiste naam geeft:

```js
function itemFieldName(record, gowamName, logisticsName) {
  if (record.uuid === undefined) {
    return gowamName;
  }

  return logisticsName;
}
```

Lees en schrijf daarna met `item[itemFieldName(item, "salePrice", "saleprice")]`.

## Fouten

- **Valideren, Kan opslaan en Voor het opslaan**: wanneer uw functie een fout opwerpt, toont Gowam de fouttekst aan de gebruiker. Bij Kan opslaan en Voor het opslaan slaat Gowam niet op.
- **Na formulier opbouwen, Menu-item en Functie**: wanneer uw functie een fout opwerpt of iets verkeerds teruggeeft, gaat Gowam verder alsof er geen plugin is.
- **Lijst/Formulier**: een methode die een fout opwerpt, toont de fouttekst, of niets.

Gebruik `pluginPrint` om te zien wat uw code doet. **Controleren** toont de laatste berichten (zie [Een plugin controleren](#een-plugin-controleren)).

## Een plugin controleren

Klik op **Controleren** in de plugin om te zien of Gowam hem echt uitvoert. De controle toont:

- **Plugin**: wanneer Gowam de plugin heeft geladen, of waarom Gowam hem niet uitvoert: de plugin is niet actief, de code bevat een fout, of een bron is na het laden gewijzigd en u moet de plugin opnieuw opslaan.
- **Gebeurtenissen registreren**: een kaart voor elke regel. Een groene kaart is een regel die Gowam aanroept. Een grijze kaart is een regel die uit staat. Een oranje of rode kaart zegt wat er fout is, bijvoorbeeld:
    - de functie staat niet in de geladen code: een foute naam, of een bron die niet actief is;
    - de pagina bestaat niet, of de pagina roept deze gebeurtenis nooit aan: Kan opslaan en Voor het opslaan werken alleen op `Item` en `Doc`, Na formulier opbouwen alleen met de types `form` en `preview`;
    - een andere regel of een andere plugin gebruikt dezelfde gebeurtenis, dus Gowam roept er maar één aan;
    - Gowam heeft geen menu met deze naam, of roept nooit een functie met deze naam aan. Gowam roept Menu-item nooit aan voor het zijmenu `main`;
    - een regel op de pagina `DocRow` werkt alleen in het rijformulier dat apart opent, vanuit het blad van een document. Voor een rij in het document geeft de controle de regel `Doc` die u moet toevoegen;
    - nadat u de pagina één keer hebt geopend: de pagina heeft het veld nooit getoond (een foute veldnaam), of het veld is van een type dat Valideren nooit aanroept, bijvoorbeeld labels of markdown. Voordat u de pagina opent, vraagt de kaart u om ze te openen.
- **Aanroepen sinds het laden**: een kaart voor elke functie die Gowam kan aanroepen, met de pagina en het veld. Ze toont het aantal aanroepen, het uur van de laatste aanroep en het laatste antwoord van uw functie, of dat Gowam ze nog niet heeft aangeroepen.
- **Laatste pluginberichten**: de laatste teksten van `pluginPrint` en de fouten van alle plugins, de nieuwste eerst.

Gowam telt de aanroepen sinds het laatste laden. Wanneer u een plugin opslaat, laadt Gowam alle plugins opnieuw en beginnen de tellers weer bij 0. Gebruik de pagina die uw functie aanroept en klik dan op **Opnieuw controleren**.

Wanneer u een plugin opslaat en een regel niet zal werken, opent Gowam de controle.

Wanneer de controle een probleem vindt, klikt u op **Oplossen met AI**. De AI-agent van de plugin opent, krijgt de lijst van de problemen en verbetert de registratieregels. Er is nog niets opgeslagen: de controle toont nog de oude problemen. Klik op **Opslaan en controleren** onder de chat. Gowam slaat de plugin op, laadt hem en controleert hem opnieuw.

Wanneer het veld Gebeurtenissen registreren wijzigingen heeft die niet zijn opgeslagen, toont de controle ook **Opslaan en controleren**.

## De code schrijven in VS Code

Op Windows, macOS en Linux heeft de broncodepagina de knoppen **Openen in VS Code** en **Importeren uit VS Code**. Gowam schrijft uw bronnen in een map, met de map `gowam_api` die `Field`, `GenControl`, `LDAO` en `Cmd` beschrijft, zodat VS Code hun namen kan aanvullen. Wanneer u klaar bent, slaat u op in VS Code en klikt u op **Importeren uit VS Code**. Gowam controleert de code en laadt die.

## Goede praktijken

- Alle plugins delen één JavaScript-ruimte. Laat uw functienamen beginnen met een kort woord voor uw plugin (`itemCheckCode`), zodat twee plugins nooit dezelfde naam gebruiken.
- Gebruik buiten een functie `function` en `var`, niet `const` of `let`. Als twee plugins dezelfde naam met `const` gebruiken, laadt de code van de tweede plugin niet.
- Test met **Ontwikkelaarsmodus** aan en kijk in het logbestand.
