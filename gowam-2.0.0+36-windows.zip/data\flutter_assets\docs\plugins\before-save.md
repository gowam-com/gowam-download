# Before Save

Gowam calls your function when it has filled the record with the values of the form, just before it writes the record. Your function can check the record and refuse the save.

Gowam calls Before Save on two pages:

- `Item`: when the user saves an item.
- `Doc`: when the user clicks **Save** to finish a document, after the checks of Gowam. `object` is the document without its rows. For a new document, Gowam sets the number, and the date when it is empty, after Before Save.

The other pages never call Before Save. To see if Gowam calls your line, click **Check** in the plugin (see [Check a plugin](index.md#check-a-plugin)).

## Register

```js
registerBeforeSave({page: "Item", function: "itemBeforeSave"});
```

| Parameter | |
|---|---|
| `page` | the name of the page |
| `function` | the name of your function |
| `active` | `false` switches the line off |

## Your function

```js
function itemBeforeSave(controls, tableName, object) {
  return "";
}
```

- `controls`: the controls of the form.
- `tableName`: the name of the page.
- `object`: the record as Gowam will write it. The names of its fields depend on the database (see [Records](index.md#records)). Gowam leaves out the fields that are empty or `0`.

Return `""` to save. Return a text to refuse: Gowam does not save and shows the text to the user.

A change to `object` has no effect: Gowam writes its own record.

[Can Save](can-save.md) runs earlier and sees only the form. Before Save sees the record, with the values that Gowam calculated.

## Example 1: refuse a sale price under the purchase price

```js
registerBeforeSave({page: "Item", function: "itemCheckMargin"});
```

```js
function itemCheckMargin(controls, tableName, object) {
  var salePrice = object.salePrice || object.saleprice || 0;
  var purchasePrice = object.purchasePrice || object.buyprice || 0;

  if (salePrice > 0 && salePrice < purchasePrice) {
    return "The sale price is lower than the purchase price";
  }

  return "";
}
```

## Example 2: the item needs a name

```js
registerBeforeSave({page: "Item", function: "itemNeedName"});
```

```js
function itemNeedName(controls, tableName, object) {
  var names = object.names || [];

  if (names.length === 0 || names[0].trim() === "") {
    return "Type a name for the item";
  }

  return "";
}
```

## Example 3: write each save in the log

The function never refuses. It writes a line in the Gowam log file (**Tools > Log > LOG files**).

```js
registerBeforeSave({page: "Item", function: "itemLogSave"});
```

```js
function itemLogSave(controls, tableName, object) {
  var code = object.itemId || object.artid;

  pluginPrint("Item saved: " + code);

  return "";
}
```
