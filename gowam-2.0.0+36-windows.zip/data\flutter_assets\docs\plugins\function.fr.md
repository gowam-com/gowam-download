# Fonction

Gowam appelle une fonction qui a un nom fixe à un moment fixe et utilise la valeur que la fonction retourne. Enregistrez la fonction avec ce nom.

Pour l'instant, Gowam appelle une seule fonction : `ItemPriceLDAO_getPrice`. Elle donne le prix d'un article quand l'utilisateur ajoute l'article à un document (facture, commande, caisse).

## Enregistrement

```js
registerFunction({function: "ItemPriceLDAO_getPrice"});
```

| Paramètre | |
|---|---|
| `function` | le nom que Gowam appelle |
| `active` | `false` désactive la ligne |

Le nom est fixe, donc un seul plugin peut le donner. Si deux plugins définissent la même fonction, Gowam utilise la dernière.

## Votre fonction

```js
function ItemPriceLDAO_getPrice(args) {
  return null;
}
```

`args` est un objet :

| Champ | |
|---|---|
| `itemId` | le code de l'article |
| `journalId` | le code du journal du document, `""` quand il n'y a pas de journal |
| `thirdPartyId` | le code du client ou du fournisseur, `""` quand il n'y en a pas |
| `sizeIndex` | la taille de l'article, `-1` quand l'article n'a pas de tailles |
| `date` | `null` pour l'instant |
| `qty` | `1` pour l'instant |

Retournez `{price: "12.50"}` pour donner le prix. **Le prix doit être un texte** : utilisez `price.toFixed(2)`. Un nombre provoque une erreur.

Retournez `null` pour laisser Gowam calculer le prix comme d'habitude.

Donnez le même type de prix que Gowam : le prix TVA comprise pour un journal avec TVA incluse (comme la caisse), le prix hors TVA pour les autres journaux.

## Exemple 1 : un prix pour un article

```js
registerFunction({function: "ItemPriceLDAO_getPrice"});
```

```js
function ItemPriceLDAO_getPrice(args) {
  if (args.itemId === "BASKET") {
    return {price: "9.00"};
  }

  return null;
}
```

## Exemple 2 : un prix pour un client

```js
registerFunction({function: "ItemPriceLDAO_getPrice"});
```

```js
function ItemPriceLDAO_getPrice(args) {
  if (args.thirdPartyId === "C0001" && args.itemId === "COFFEE") {
    return {price: "2.50"};
  }

  return null;
}
```

## Exemple 3 : une promotion entre deux dates

```js
registerFunction({function: "ItemPriceLDAO_getPrice"});
```

```js
function ItemPriceLDAO_getPrice(args) {
  var today = new Date().toISOString().substring(0, 10);

  if (args.itemId === "COFFEE" && today >= "2026-12-01" && today <= "2026-12-31") {
    return {price: "1.99"};
  }

  return null;
}
```

## Exemple 4 : un prix pour le personnel

Dans le journal `STAFF`, le prix est le prix d'achat plus 10 %. La fonction lit l'article dans la base de données.

```js
registerFunction({function: "ItemPriceLDAO_getPrice"});
```

```js
function ItemPriceLDAO_getPrice(args) {
  if (args.journalId !== "STAFF") {
    return null;
  }

  var item = LDAO.getByKeySync("Item", args.itemId);

  if (item === null) {
    return null;
  }

  var purchasePrice = item.purchasePrice || item.buyprice || 0;

  if (purchasePrice === 0) {
    return null;
  }

  return {price: (purchasePrice * 1.1).toFixed(2)};
}
```

## Exemple 5 : un prix venant d'un service web

La fonction demande le prix à votre propre service web. Le service répond avec un texte JSON comme `{"price": 2.5}`. Si le service ne répond pas ou ne connaît pas l'article, Gowam calcule le prix comme d'habitude. L'en-tête `Authorization` donne la clé de votre service.

```js
registerFunction({function: "ItemPriceLDAO_getPrice"});
```

```js
async function ItemPriceLDAO_getPrice(args) {
  var url = "https://prices.example.com/price?item=" + encodeURIComponent(args.itemId) + "&customer=" + encodeURIComponent(args.thirdPartyId);
  var answer = await httpRequest("GET", url, "", {"Authorization": "Bearer 1234567890"});

  if (answer.statusCode !== 200) {
    return null;
  }

  var price = JSON.parse(answer.body).price;

  if (typeof price !== "number") {
    return null;
  }

  return {price: price.toFixed(2)};
}
```
