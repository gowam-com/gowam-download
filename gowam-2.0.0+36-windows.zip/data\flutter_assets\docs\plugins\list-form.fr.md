# Liste/Formulaire

Un plugin Liste/Formulaire ajoute une page complète à Gowam : une liste de cartes et un formulaire, comme les pages de Gowam. Gowam appelle les méthodes d'un objet que votre code définit.

## Enregistrement

```js
registerListForm({page: "ItemsWithoutReference", class: "ItemsWithoutReference", listSearch: true, listPreview: false, listAdd: false, listForm: true, listMaxWidth: 1200, formDelete: false, formSave: true, formMaxWidth: 800, listCardsCount: 20});
```

| Paramètre | |
|---|---|
| `page` | le nom de votre page. Utilisez un nom que Gowam n'utilise pas |
| `class` | le nom de l'objet dans votre code |
| `listSearch` | afficher une zone de recherche au-dessus de la liste |
| `listPreview` | afficher un aperçu quand l'utilisateur clique sur une carte. Avec `false`, le clic ouvre le formulaire |
| `listAdd` | afficher le bouton qui ajoute un enregistrement |
| `listForm` | la liste a un formulaire |
| `listMaxWidth`, `formMaxWidth` | la largeur maximale de la liste et du formulaire, en pixels |
| `formDelete`, `formSave` | afficher les boutons de suppression et d'enregistrement dans la barre de titre du formulaire |
| `listCardsCount` | le nombre de cartes que Gowam demande à chaque fois |
| `backgroundColors` | les couleurs du fond, par exemple `["#ffffff", "#f5f5f5", "#e3f2fd"]` |
| `active` | `false` désactive la ligne |

Pour ouvrir la page, ajoutez une entrée à un menu avec un plugin [Élément de menu](menu-item.md#exemple-4-ouvrir-votre-propre-page) : `type: "list"` et `childTableName` = le nom de votre page.

## Les méthodes

Définissez toutes les méthodes, aussi celles dont vous n'avez pas besoin. Une méthode peut être `async`.

| Méthode | Retour |
|---|---|
| `genListGetTitle(parentId, parentTableName, args)` | le titre de la liste |
| `genListFirstControls(parentId, parentTableName, args)` | les contrôles au-dessus de la liste, `[]` pour aucun |
| `genListGetCards(filter, offset, count, parentId, parentTableName, controls, args)` | les cartes : `count` cartes à partir de la carte numéro `offset`. `filter` est le texte de la zone de recherche. `LDAO.getListFilterSync` cherche ce texte dans les champs de `listSearchProperties` |
| `genListGetCard(objectId, parentTableName, parentId, controls, args)` | la carte d'un enregistrement |
| `genListNavigateBack(controls)` | `""` |
| `genPreviewGetControls(objectId, isSelect, args)` | les contrôles de l'aperçu, `[]` pour aucun |
| `genGetDropdownDisplay(id, args)` | le texte qu'une liste déroulante affiche pour cet enregistrement |
| `genGetSearchCode(id, args)` | le code de l'enregistrement |
| `genFormGetTitle(objectId, parentId, parentTableName, subForm, args)` | le titre du formulaire |
| `genFormGetControls(objectId, parentId, parentTableName, subForm, source, searchControls, args)` | les contrôles du formulaire |
| `genFormSave(controls, objectId, parentId, parentTableName, fromSaveButton, subForm, args)` | l'id de l'enregistrement enregistré, `0` s'il n'a pas été enregistré |
| `genFormDelete(objectId, args)` | l'id de l'enregistrement supprimé, `0` s'il n'a pas été supprimé |
| `genFormNavigateBack(controls, objectId)` | `""` |

Retournez des listes et des objets, pas des textes JSON. `args` est un texte JSON, ou `""`.

Une carte est un objet avec l'id de l'enregistrement et des colonnes de contrôles :

```js
{
  objectId: 12,
  columns: [
    {width: 100, widthType: "variablePercentage", controls: [GenControl.text({fieldName: "title", label: "COFFEE"})]}
  ]
}
```

`widthType` vaut `"variablePercentage"` (la largeur est un pourcentage) ou `"fixedPixels"` (la largeur est en pixels).

## Exemple 1 : les articles sans référence fournisseur

La page affiche les articles qui n'ont pas de référence fournisseur. Un clic sur un article ouvre un formulaire où l'utilisateur tape la référence.

```js
registerListForm({page: "ItemsWithoutReference", class: "ItemsWithoutReference", listSearch: true, listPreview: false, listAdd: false, listForm: true, listMaxWidth: 1200, formDelete: false, formSave: true, formMaxWidth: 800, listCardsCount: 20});
```

La fonction `itemFieldName` donne le nom d'un champ dans une base de données Gowam ou dans une base de données logistique (voir [Enregistrements](index.md#enregistrements)).

```js
function itemFieldName(record, gowamName, logisticsName) {
  if (record.uuid === undefined) {
    return gowamName;
  }

  return logisticsName;
}

function itemTitle(item) {
  var code = item[itemFieldName(item, "itemId", "artid")];
  var names = item.names || [];

  return code + " " + (names[0] || "");
}

function itemCard(item) {
  return {
    objectId: item._id,
    columns: [
      {
        width: 100,
        widthType: "variablePercentage",
        controls: [
          GenControl.text({fieldName: "title", label: itemTitle(item), textStyle: {fontWeight: "bold", fontSize: 16}})
        ]
      }
    ]
  };
}

var ItemsWithoutReference = {
  genListGetTitle: function (parentId, parentTableName, args) {
    return "Items without a supplier reference";
  },

  genListFirstControls: function (parentId, parentTableName, args) {
    return [];
  },

  genListGetCards: function (filter, offset, count, parentId, parentTableName, controls, args) {
    var items = LDAO.getListFilterSync("Item", {
      search: filter,
      listSearchProperties: ["itemId", "names"],
      filters: {supplierReference: ""},
      offset: offset,
      count: count
    });

    return items.map(itemCard);
  },

  genListGetCard: function (objectId, parentTableName, parentId, controls, args) {
    return itemCard(LDAO.getSync("Item", objectId));
  },

  genListNavigateBack: function (controls) {
    return "";
  },

  genPreviewGetControls: function (objectId, isSelect, args) {
    return [];
  },

  genGetDropdownDisplay: function (id, args) {
    return itemTitle(LDAO.getSync("Item", id));
  },

  genGetSearchCode: function (id, args) {
    var item = LDAO.getSync("Item", id);

    return item[itemFieldName(item, "itemId", "artid")];
  },

  genFormGetTitle: function (objectId, parentId, parentTableName, subForm, args) {
    return "Supplier reference";
  },

  genFormGetControls: function (objectId, parentId, parentTableName, subForm, source, searchControls, args) {
    var item = LDAO.getSync("Item", objectId);

    return [
      GenControl.text({fieldName: "itemTitleText", label: itemTitle(item), textStyle: {fontWeight: "bold", fontSize: 16}}),
      Field.stringControl({fieldName: "itemReference", label: "Supplier reference", text: "", maxLength: 30}),
      GenControl.buttonSave()
    ];
  },

  genFormSave: async function (controls, objectId, parentId, parentTableName, fromSaveButton, subForm, args) {
    var reference = Field.stringGet(controls, "itemReference");

    if (reference === "") {
      return 0;
    }

    var item = LDAO.getSync("Item", objectId);

    item[itemFieldName(item, "supplierReference", "buyartid")] = reference;
    await LDAO.save("Item", item);

    return objectId;
  },

  genFormDelete: function (objectId, args) {
    return 0;
  },

  genFormNavigateBack: function (controls, objectId) {
    return "";
  }
};
```

## Exemple 2 : les ventes d'un article

La page affiche l'historique des ventes d'un article : ses lignes de documents dans un tableau, avec la marge. Elle n'a pas de liste : le bouton **Statistics** de [Après construction du formulaire](after-build.md#exemple-6-un-bouton-statistiques-dans-lapercu) ouvre son formulaire avec l'id de l'article. Les fonctions `itemFieldName` et `itemTitle` de l'exemple 1 doivent aussi être dans votre code.

```js
registerListForm({page: "ItemPluginStatistics", class: "ItemPluginStatistics", listSearch: false, listPreview: false, listAdd: false, listForm: true, formDelete: false, formSave: false});
```

```js
function itemSalesRow(row) {
  var amount = row.amount || 0;
  var costAmount = row[itemFieldName(row, "costAmount", "costamount")] || 0;

  return [
    row[itemFieldName(row, "journalId", "jnl")] || "",
    String(row.number || ""),
    String(row.date || "").substring(0, 10),
    row.qty || 0,
    row[itemFieldName(row, "unitPrice", "unitprice")] || 0,
    row[itemFieldName(row, "discountPc", "discount")] || 0,
    amount,
    costAmount,
    amount - costAmount
  ];
}

var ItemPluginStatistics = {
  genListGetTitle: function (parentId, parentTableName, args) {
    return "Sales history";
  },

  genListFirstControls: function (parentId, parentTableName, args) {
    return [];
  },

  genListGetCards: function (filter, offset, count, parentId, parentTableName, controls, args) {
    return [];
  },

  genListGetCard: function (objectId, parentTableName, parentId, controls, args) {
    return {};
  },

  genListNavigateBack: function (controls) {
    return "";
  },

  genPreviewGetControls: function (objectId, isSelect, args) {
    return [];
  },

  genGetDropdownDisplay: function (id, args) {
    return "";
  },

  genGetSearchCode: function (id, args) {
    return "";
  },

  genFormGetTitle: function (objectId, parentId, parentTableName, subForm, args) {
    return "Sales history";
  },

  genFormGetControls: function (objectId, parentId, parentTableName, subForm, source, searchControls, args) {
    var item = LDAO.getSync("Item", objectId);
    var rows = getDocRowsByItemId(item[itemFieldName(item, "itemId", "artid")]);
    var controls = [GenControl.text({fieldName: "itemSalesTitle", label: itemTitle(item), textStyle: {fontWeight: "bold", fontSize: 16}})];

    if (rows.length === 0) {
      controls.push(GenControl.text({fieldName: "itemSalesNone", label: "No history found for this item."}));

      return controls;
    }

    controls.push(GenControl.text({fieldName: "itemSalesCount", label: "History (" + rows.length + " records)"}));
    controls.push(GenControl.gowamSheetViewer({
      fieldName: "itemSalesSheet",
      gowamSheet: {
        titles: ["Journal", "Number", "Date", "Quantity", "Unit price", "Discount", "Amount", "Cost amount", "Margin"],
        types: ["String", "String", "String", "double", "double", "double", "double", "double", "double"],
        data: rows.map(itemSalesRow)
      }
    }));

    return controls;
  },

  genFormSave: function (controls, objectId, parentId, parentTableName, fromSaveButton, subForm, args) {
    return 0;
  },

  genFormDelete: function (objectId, args) {
    return 0;
  },

  genFormNavigateBack: function (controls, objectId) {
    return "";
  }
};
```
