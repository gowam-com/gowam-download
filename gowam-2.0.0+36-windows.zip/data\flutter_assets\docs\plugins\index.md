# Plugins

A plugin adds your own JavaScript code to Gowam. With a plugin you can check a field, change a form, add a menu entry, refuse a save, give the price of an item or add a complete new page. You do not change Gowam itself.

## Create a plugin

1. Open **Settings > Plugins** and add a plugin. Give it a code (for example `item_rules`), a description, an author and a version. Switch on **Active** and save.
2. Open the plugin again and click **Source code**. Add a source: give it a name and write your JavaScript code. A plugin can have several sources. Gowam joins them in one file.
3. Go back to the plugin and write the lines of **Register events JS code**. Each line tells Gowam when to call one of your functions (see [The Register events field](#the-register-events-field)).
4. Click **Save** in the plugin. Gowam checks the code and loads it. Your code runs from now on.

**Note:** Gowam loads the code when you save the plugin, not when you save a source. After you change a source, open the plugin and click **Save** again. **Check** tells you when a source changed after the load (see [Check a plugin](#check-a-plugin)).

## The types of plugins

| Type | Register line | Gowam calls your function |
|---|---|---|
| [Validate](validate.md) | `registerValidate` | when the user changes a field or clicks a button |
| [After Build](after-build.md) | `registerAfterBuildUI` | when a form is ready, just before Gowam shows it |
| [Menu Item](menu-item.md) | `registerBuildMenu` | when Gowam opens a menu |
| [Can Save](can-save.md) | `registerCanSave` | when the user saves, before Gowam reads the form |
| [Before Save](before-save.md) | `registerBeforeSave` | when the record is ready, just before Gowam writes it |
| [Function](function.md) | `registerFunction` | when Gowam needs a value that a plugin can give |
| [List/Form](list-form.md) | `registerListForm` | to show your own page with a list and a form |

Every register line also accepts `active: false`, to switch the line off without deleting it, and `description: "..."`, for your own notes.

Gowam keeps one function for each event. If two lines register the same page and field (or the same page and type, or the same menu), Gowam uses the last one.

## The Register events field

The field **Register events JS code** of the plugin tells Gowam which of your functions to call, and when. Write one line for each event:

```js
registerValidate({page: "Item", field: "@itemId", function: "itemCheckCode", before: true});
registerCanSave({page: "Item", function: "itemNeedComment"});
registerFunction({function: "ItemPriceLDAO_getPrice"});
```

- Each line calls one of the register functions of the table above, with the parameters between `{` and `}`. The page of each type gives its parameters.
- Put the texts between quotes: `function: "itemCheckCode"`. `true`, `false` and the numbers have no quotes.
- `function` is the name of a function in your source code. When you save the plugin, Gowam opens the check if this function is not in the loaded code (see [Check a plugin](#check-a-plugin)). When the name is wrong, Gowam does as when your function throws an error (see [Errors](#errors)).
- Write only register lines here. Your functions go in the **Source code**.

**Add event** adds a line with all the parameters of a type. Replace `TableName`, `fieldName` and `methodName` with your names.

**View Json** shows the events as Gowam will save them, or the error.

When you click **Save**, Gowam checks each line. If a line is wrong, Gowam does not save and shows the error. The error starts with the register function and its number: `registerValidate (call 2)` is the second `registerValidate` line.

| The error says | Do this |
|---|---|
| `missing required parameter 'field'` | add the parameter |
| `unknown parameter 'fonction'` | correct the name of the parameter. The error gives the correct names |
| `invalid value for parameter 'active'` | remove the quotes: `active: false` |
| `parameter 'function' cannot be empty` | type the name |
| `invalid type 'Preview'` | `type` is `"form"`, `"list"`, `"preview"` or `"menu"` |
| `an event with the same parameters is already registered` | remove one of the two lines |
| `JavaScript Error` and the name of your function | put the name between quotes |
| `JavaScript Error` and the name of a register function | write the register function exactly as in the table above, with the same capital letters |
| `JavaScript Error` and another text | correct the JavaScript, for example add a missing `)` or `}` |

Gowam saves the events, not your text. When you open the plugin again, Gowam writes the lines again from the events: it adds the parameters that have a default value, such as `type: "form"` and `active: true`, and removes the comments and the empty lines. The three lines above become:

```js
registerValidate({page: "Item", type: "form", field: "@itemId", function: "itemCheckCode", before: true, active: true});
registerCanSave({page: "Item", type: "form", function: "itemNeedComment", active: true});
registerFunction({function: "ItemPriceLDAO_getPrice", active: true});
```

To switch a line off without deleting it, change `active: true` to `active: false` and save the plugin.

## Find the names of the pages and fields

Switch on **Developer mode** at the top of the **Plugins** list. Then:

- Every title bar shows a developer icon. Put the mouse on this icon to see the name of the page, or of the menu on a menu page. Use this name for `page:` and `menu:`. Click the icon to open the **Plugins** list.
- Put the mouse on a field to see its field name. Use this name for `field:` and in your code.

Field names keep their first character: `@itemId`, `€purchaseQty`, `!stockMethod`, `-€salePrice`. Type them exactly as Gowam shows them.

Some page names: `Item`, `ThirdParty`, `Doc`, `DocRow`, `Journal`.

The list, the preview and the form of a table use the same page name. For the items, all three are `Item`. In [After Build](after-build.md), `type` says which one you change.

## The controls

A form is a list of controls. Gowam gives this list to your function. Each control is an object:

```js
{
  fieldName: "@itemId",
  controlType: "textField",
  label: "Code",
  value: "COFFEE",
  isVisible: true,
  isReadOnly: false
}
```

The value of a text field is a text, also for numbers (`"12.50"`). The value of a switch or a check box is `true` or `false`. The value of a dropdown that points to a record, such as `@unit`, is the id of that record (`0` when empty).

Your function gets a copy of the controls. To change the form, return the controls ([After Build](after-build.md)) or return `Cmd.updatedMaps` with the controls ([Validate](validate.md)).

## The tools in your code

Gowam loads these objects before your code. You can use them everywhere.

| Object | For |
|---|---|
| `Field` | read and change controls: `Field.getControl(controls, "@itemId")`, `Field.stringGet`, `Field.integerGet`, `Field.floatGet`, `Field.booleanGet`, `Field.lookupGet`, `Field.stringSet`, `Field.floatSet`, `Field.setVisible`, `Field.setReadOnly`, `Field.setLabel`, `Field.getControlIndex`, `Field.removeControl` |
| `GenControl` | make new controls: `GenControl.textField({...})`, `GenControl.text`, `GenControl.separator`, `GenControl.switchBox`, `GenControl.dropdown`, `GenControl.buttonFunction` |
| `LDAO` | read and write records: `LDAO.getSync("Item", id)`, `LDAO.getByKeySync("Item", "COFFEE")`, `LDAO.getListFilterSync("Item", {filters: {...}, count: 20})`, `LDAO.countAllSync("Item")`, `await LDAO.save("Item", item)` |
| `Cmd` | commands that you can return: `Cmd.updatedMaps`, `Cmd.updateControls`, `Cmd.refresh`, `Cmd.closeForm`, `Cmd.setFocus("@comment")` |
| `pluginPrint` | `pluginPrint("text")` writes a line in the Gowam log file (**Tools > Log > LOG files**) |
| `httpRequest` | `await httpRequest("POST", url, body, headers)` calls a web service and gives `{statusCode, body}`. `statusCode` is `-1` when the service does not answer |
| `getDocRowsByItemId` | `getDocRowsByItemId("COFFEE")` gives the document rows of an item |
| `getItemIdById` | `getItemIdById(12)` gives the code of the item with the id `12` |
| `navigateToForm` | `navigateToForm(objectId, "Item", "", 0, "Title", "", null, null, false)` opens a form |
| `navigateToList` | `navigateToList("Item", "", 0, false, false, null, null)` opens a list |
| `navigateToMenu` | `navigateToMenu("Settings", "main_settings")` opens a menu |

A function can be `async` and use `await`. Gowam waits for the result.

## Records

`LDAO` gives records as objects. `_id` is the id of the record in this device. Keep it: when you save an object that has an `_id`, Gowam changes this record and does not add a new one.

Gowam leaves out the fields that are empty or `0`. Read them with a default value: `item.salePrice || 0`.

The names of the fields depend on the database:

| Gowam database | Logistics database |
|---|---|
| `itemId` | `artid` |
| `salePrice` | `saleprice` |
| `supplierReference` | `buyartid` |

The filters of `LDAO.getListFilterSync` always use the Gowam names. If your plugin must work with both databases, use a small function that gives the correct name:

```js
function itemFieldName(record, gowamName, logisticsName) {
  if (record.uuid === undefined) {
    return gowamName;
  }

  return logisticsName;
}
```

Then read and write with `item[itemFieldName(item, "salePrice", "saleprice")]`.

## Errors

- **Validate, Can Save and Before Save**: when your function throws an error, Gowam shows the error text to the user. With Can Save and Before Save, Gowam does not save.
- **After Build, Menu Item and Function**: when your function throws an error or returns something wrong, Gowam continues as if there was no plugin.
- **List/Form**: a method that throws an error shows the error text, or nothing.

Use `pluginPrint` to see what your code does. **Check** shows the last messages (see [Check a plugin](#check-a-plugin)).

## Check a plugin

Click **Check** in the plugin to see if Gowam really runs it. The check shows:

- **Plugin**: when Gowam loaded the plugin, or why Gowam does not run it: the plugin is not active, the code has an error, or a source changed after the load and you must save the plugin again.
- **Register events**: one card for each line. A green card is a line that Gowam calls. A grey card is a line that is off. An orange or red card tells what is wrong, for example:
    - the function is not in the loaded code: a wrong name, or a source that is not active;
    - the page does not exist, or the page never calls this event: Can Save and Before Save run only on `Item` and `Doc`, After Build only with the types `form` and `preview`;
    - another line or another plugin uses the same event, so Gowam calls only one of them;
    - Gowam has no menu with this name, or never calls a function with this name. Gowam never calls Build Menu for the side menu `main`;
    - a line on the page `DocRow` runs only in the row form that opens alone, from the sheet of a document. For a row inside the document, the check gives the `Doc` line to add;
    - after you open the page once: the page never showed the field (a wrong field name), or the field is of a type that never calls Validate, for example labels or markdown. Before you open the page, the card asks you to open it.
- **Calls since the load**: one card for each function that Gowam can call, with the page and field. It shows the number of calls, the time of the last call and the last answer of your function, or that Gowam has not called it yet.
- **Last plugin messages**: the last texts of `pluginPrint` and the errors of all the plugins, the newest first.

Gowam counts the calls from the last load. When you save a plugin, Gowam loads all the plugins again and the counts start again at 0. Use the page that calls your function, then click **Check again**.

When you save a plugin and a line will not run, Gowam opens the check.

When the check finds a problem, click **Fix with AI**. The AI Agent of the plugin opens, gets the list of the problems and corrects the register lines. Nothing is saved yet: the check still shows the old problems. Click **Save and check** under the chat. Gowam saves the plugin, loads it and checks it again.

When the Register events field has changes that are not saved, the check also shows **Save and check**.

## Write the code in VS Code

On Windows, macOS and Linux, the source code page has the buttons **Open in VS Code** and **Import from VS Code**. Gowam writes your sources in a folder, with the folder `gowam_api` that describes `Field`, `GenControl`, `LDAO` and `Cmd`, so VS Code can complete their names. When you are done, save in VS Code and click **Import from VS Code**. Gowam checks the code and loads it.

## Good practice

- All plugins share one JavaScript space. Start your function names with a short word for your plugin (`itemCheckCode`), so that two plugins never use the same name.
- Outside a function, use `function` and `var`, not `const` or `let`. If two plugins use the same `const` name, the code of the second plugin does not load.
- Test with **Developer mode** on, and look at the log file.
