# Functie

Gowam roept een functie met een vaste naam aan op een vast moment en gebruikt de waarde die de functie teruggeeft. Registreer de functie met deze naam.

Op dit moment roept Gowam één functie aan: `ItemPriceLDAO_getPrice`. Deze functie geeft de prijs van een artikel wanneer de gebruiker het artikel aan een document toevoegt (factuur, bestelling, kassa).

## Registreren

```js
registerFunction({function: "ItemPriceLDAO_getPrice"});
```

| Parameter | |
|---|---|
| `function` | de naam die Gowam aanroept |
| `active` | `false` zet de regel uit |

De naam is vast, dus maar één plugin kan deze functie geven. Als twee plugins dezelfde functie definiëren, gebruikt Gowam de laatste.

## Uw functie

```js
function ItemPriceLDAO_getPrice(args) {
  return null;
}
```

`args` is een object:

| Veld | |
|---|---|
| `itemId` | de code van het artikel |
| `journalId` | de code van het dagboek van het document, `""` als er geen dagboek is |
| `thirdPartyId` | de code van de klant of leverancier, `""` als er geen is |
| `sizeIndex` | de maat van het artikel, `-1` als het artikel geen maten heeft |
| `date` | op dit moment `null` |
| `qty` | op dit moment `1` |

Geef `{price: "12.50"}` terug om de prijs te geven. **De prijs moet een tekst zijn**: gebruik `price.toFixed(2)`. Een getal geeft een fout.

Geef `null` terug om Gowam de prijs zoals gewoonlijk te laten berekenen.

Geef dezelfde soort prijs als Gowam: de prijs met btw voor een dagboek met btw inbegrepen (zoals de kassa), de prijs zonder btw voor de andere dagboeken.

## Voorbeeld 1: een prijs voor één artikel

```js
registerFunction({function: "ItemPriceLDAO_getPrice"});
```

```js
function ItemPriceLDAO_getPrice(args) {
  if (args.itemId === "BASKET") {
    return {price: "9.00"};
  }

  return null;
}
```

## Voorbeeld 2: een prijs voor één klant

```js
registerFunction({function: "ItemPriceLDAO_getPrice"});
```

```js
function ItemPriceLDAO_getPrice(args) {
  if (args.thirdPartyId === "C0001" && args.itemId === "COFFEE") {
    return {price: "2.50"};
  }

  return null;
}
```

## Voorbeeld 3: een promotie tussen twee datums

```js
registerFunction({function: "ItemPriceLDAO_getPrice"});
```

```js
function ItemPriceLDAO_getPrice(args) {
  var today = new Date().toISOString().substring(0, 10);

  if (args.itemId === "COFFEE" && today >= "2026-12-01" && today <= "2026-12-31") {
    return {price: "1.99"};
  }

  return null;
}
```

## Voorbeeld 4: een personeelsprijs

In het dagboek `STAFF` is de prijs de inkoopprijs plus 10 %. De functie leest het artikel in de database.

```js
registerFunction({function: "ItemPriceLDAO_getPrice"});
```

```js
function ItemPriceLDAO_getPrice(args) {
  if (args.journalId !== "STAFF") {
    return null;
  }

  var item = LDAO.getByKeySync("Item", args.itemId);

  if (item === null) {
    return null;
  }

  var purchasePrice = item.purchasePrice || item.buyprice || 0;

  if (purchasePrice === 0) {
    return null;
  }

  return {price: (purchasePrice * 1.1).toFixed(2)};
}
```

## Voorbeeld 5: een prijs van een webservice

De functie vraagt de prijs aan uw eigen webservice. De service antwoordt met een JSON-tekst zoals `{"price": 2.5}`. Als de service niet antwoordt of het artikel niet kent, berekent Gowam de prijs zoals gewoonlijk. De header `Authorization` geeft de sleutel van uw service.

```js
registerFunction({function: "ItemPriceLDAO_getPrice"});
```

```js
async function ItemPriceLDAO_getPrice(args) {
  var url = "https://prices.example.com/price?item=" + encodeURIComponent(args.itemId) + "&customer=" + encodeURIComponent(args.thirdPartyId);
  var answer = await httpRequest("GET", url, "", {"Authorization": "Bearer 1234567890"});

  if (answer.statusCode !== 200) {
    return null;
  }

  var price = JSON.parse(answer.body).price;

  if (typeof price !== "number") {
    return null;
  }

  return {price: price.toFixed(2)};
}
```
