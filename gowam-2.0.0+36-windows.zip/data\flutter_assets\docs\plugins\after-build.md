# After Build

Gowam calls your function when a form is ready, just before it shows the form. Your function can hide, change, move, remove or add controls.

## Register

```js
registerAfterBuildUI({page: "Item", type: "form", function: "itemForm"});
```

| Parameter | |
|---|---|
| `page` | the name of the page (see [Find the names](index.md#find-the-names-of-the-pages-and-fields)) |
| `type` | `"form"` (default): the form. `"preview"`: the preview next to the list |
| `function` | the name of your function |
| `active` | `false` switches the line off |

Gowam keeps one function for each page and type. Put all the changes of a form in one function.

## Your function

```js
function itemForm(controls) {
  return controls;
}
```

Return the list of controls, not a JSON text. If your function throws an error or returns something wrong, Gowam shows its own form.

Each control that you add needs a `fieldName` that no other control uses.

Gowam does not save the value of a field that you add. To keep the value, save it yourself, for example in [Before Save](before-save.md) or in a [Validate](validate.md) of a button.

## Example 1: hide a field and change a label

```js
registerAfterBuildUI({page: "Item", type: "form", function: "itemForm"});
```

```js
function itemForm(controls) {
  Field.setVisible(controls, "@comment", false);
  Field.setLabel(controls, "@supplierReference", "Supplier article");

  return controls;
}
```

## Example 2: lock the code of an existing item

The field `id` contains the id of the item. It is empty for a new item.

```js
registerAfterBuildUI({page: "Item", type: "form", function: "itemLockCode"});
```

```js
function itemLockCode(controls) {
  var id = Field.integerGet(controls, "id");

  if (id > 0) {
    Field.setReadOnly(controls, "@itemId", true);
  }

  return controls;
}
```

## Example 3: add a field

The function adds a field after the code: the replacement code of the item.

```js
registerAfterBuildUI({page: "Item", type: "form", function: "itemAddReplacement"});
```

```js
function itemAddReplacement(controls) {
  var index = Field.getControlIndex(controls, "@itemId");

  if (index === null) {
    return controls;
  }

  var field = GenControl.textField({
    fieldName: "itemReplacement",
    label: "Replacement itemId",
    initialValue: ""
  });

  controls.splice(index + 1, 0, field);

  return controls;
}
```

## Example 4: add a button

The function adds a button before the **Save** button. A [Validate](validate.md) on the field name of the button runs when the user clicks it. Here the button copies the supplier reference into the comment.

```js
registerAfterBuildUI({page: "Item", type: "form", function: "itemAddCopyButton"});
registerValidate({page: "Item", field: "itemCopyButton", function: "itemCopyReference"});
```

```js
function itemAddCopyButton(controls) {
  var index = Field.getControlIndex(controls, "btnSave");
  var button = GenControl.buttonFunction({
    fieldName: "itemCopyButton",
    label: "Copy the supplier reference to the comment"
  });

  controls.splice(index, 0, button);

  return controls;
}

function itemCopyReference(controls, properties) {
  var reference = Field.stringGet(controls, "@supplierReference");

  if (reference === "") {
    return "There is no supplier reference";
  }

  Field.stringSet(controls, reference, "@comment");

  return Cmd.updatedMaps + JSON.stringify(controls);
}
```

## Example 5: change the preview

With `type: "preview"`, your function changes the preview that shows next to the list. Here it adds the replacement code above the picture of the item. In the preview, the code and the picture are in the card `names`, so the function changes the controls of this card. The picture shows when the user clicks the image icon next to the code.

```js
registerAfterBuildUI({page: "Item", type: "preview", function: "itemPreview"});
```

```js
function itemPreview(controls) {
  var names = Field.getControl(controls, "names");

  if (names === null) {
    return controls;
  }

  var cardControls = names.genCard.columns[0].controls;
  var index = Field.getControlIndex(cardControls, "picture");

  if (index === null) {
    index = Field.getControlIndex(cardControls, "addPicture");
  }

  if (index === null) {
    return controls;
  }

  var field = GenControl.textField({
    fieldName: "itemReplacementPreview",
    label: "Replacement itemId",
    initialValue: ""
  });

  cardControls.splice(index, 0, field);

  return controls;
}
```

## Example 6: a Statistics button in the preview

The button opens the page of a [List/Form](list-form.md#example-2-the-sales-of-an-item) plugin with the sales of the item. `navigateToForm` opens this page with the id of the item.

```js
registerAfterBuildUI({page: "Item", type: "preview", function: "itemAddStatisticsButton"});
registerValidate({page: "Item", field: "itemStatisticsButton", function: "itemOpenSales"});
```

```js
function itemAddStatisticsButton(controls) {
  var index = Field.getControlIndex(controls, "names");

  if (index === null) {
    index = controls.length;
  }

  var button = GenControl.buttonFunction({
    fieldName: "itemStatisticsButton",
    label: "Statistics"
  });

  controls.splice(index, 0, button);

  return controls;
}

function itemOpenSales(controls, properties) {
  var objectId = JSON.parse(properties).objectId;

  navigateToForm(objectId, "ItemPluginStatistics", "", 0, "Sales history", "", null, null, false);

  return "";
}
```
