# Menu-item

Gowam roept uw functie aan wanneer Gowam een menupagina opent, bijvoorbeeld **Instellingen**, **Hulpmiddelen** of **Andere bestanden**. Uw functie kan de menu-items van het menu toevoegen, verwijderen, hernoemen of verplaatsen.

Het zijmenu van Gowam roept geen plugins aan.

## Registreren

```js
registerBuildMenu({menu: "main_other_files", function: "itemOtherFilesMenu"});
```

| Parameter | |
|---|---|
| `menu` | de naam van het menu |
| `function` | de naam van uw functie |
| `active` | `false` zet de regel uit |

Om de naam van een menu te vinden, opent u het menu met **Ontwikkelaarsmodus** aan en houdt u de muis op het ontwikkelaarspictogram van de titelbalk. Enkele namen:

| Menu | Naam |
|---|---|
| Acties | `main_action` |
| Andere bestanden | `main_other_files` |
| Proces | `main_process` |
| Rapport | `main_reports` |
| Hulpmiddelen | `main_tools` |
| Instellingen | `main_settings` |
| Instellingen / Opties | `settings_options` |
| Instellingen / Artikelen | `settings_item_settings` |

## Uw functie

```js
function itemOtherFilesMenu(items) {
  return items;
}
```

`items` is de lijst van de menu-items van het menu. Geef de lijst terug, geen JSON-tekst. Elk menu-item is een object:

```js
{
  key: "of_lookup_UNIT",
  type: "list",
  title: "Unit of measure",
  childTableName: "UNIT",
  argument: "",
  rightCode: "",
  useKey: "",
  isLight: false,
  icon: {icon: 0xf065b, color: "#FF455A64", size: 24}
}
```

| Veld | |
|---|---|
| `key` | een naam die geen ander menu-item gebruikt |
| `type` | `"list"` opent de lijst van de pagina `childTableName`, `"form"` opent het formulier van die pagina, `"menu"` opent het menu `childTableName`, `"separator"` is een lijn |
| `title` | de tekst van het menu-item |
| `childTableName` | de naam van de pagina of van het menu |
| `argument`, `rightCode`, `useKey` | laat `""` staan voor uw menu-items |
| `icon` | de code van een [Flutter Material-pictogram](https://api.flutter.dev/flutter/material/Icons-class.html) (het getal in `IconData(0xe34a, ...)`) en de kleur ervan als `#AARRGGBB`, of `{}` voor geen pictogram |

Een nieuw menu-item heeft alle tekstvelden nodig: `title`, `childTableName`, `argument`, `rightCode` en `useKey`. Als er een ontbreekt, gebruikt Gowam de wijzigingen van uw functie niet.

De menu-items van het type `"function"` zijn de menu-items van Gowam. U kunt ze verplaatsen, hernoemen of verwijderen. U kunt er geen nieuwe maken.

## Voorbeeld 1: een menu-item toevoegen

De functie voegt een menu-item toe aan het einde van **Andere bestanden**. Het menu-item opent de lijst van de artikelen.

```js
registerBuildMenu({menu: "main_other_files", function: "itemOtherFilesMenu"});
```

```js
function itemOtherFilesMenu(items) {
  items.push({
    key: "item_list",
    type: "list",
    title: "Items",
    childTableName: "Item",
    argument: "",
    rightCode: "",
    useKey: "",
    icon: {icon: 0xe34a, color: "#FF1565C0", size: 24}
  });

  return items;
}
```

## Voorbeeld 2: een menu-item verwijderen

```js
registerBuildMenu({menu: "main_other_files", function: "itemHideFamily"});
```

```js
function itemHideFamily(items) {
  return items.filter(function (item) {
    return item.key !== "of_lookup_ARTFAMILY";
  });
}
```

## Voorbeeld 3: een menu-item hernoemen en bovenaan zetten

```js
registerBuildMenu({menu: "main_other_files", function: "itemUnitsFirst"});
```

```js
function itemUnitsFirst(items) {
  for (var i = 0; i < items.length; i++) {
    if (items[i].key === "of_lookup_UNIT") {
      var unit = items.splice(i, 1)[0];

      unit.title = "Units";
      items.unshift(unit);

      return items;
    }
  }

  return items;
}
```

## Voorbeeld 4: uw eigen pagina openen

Een scheidingslijn en een menu-item dat de pagina van een plugin [Lijst/Formulier](list-form.md) opent.

```js
registerBuildMenu({menu: "main_other_files", function: "itemAddReferencePage"});
```

```js
function itemAddReferencePage(items) {
  items.push({
    key: "itemSeparator",
    type: "separator",
    title: "",
    childTableName: "",
    argument: "",
    rightCode: "",
    useKey: ""
  });

  items.push({
    key: "itemsWithoutReference",
    type: "list",
    title: "Items without a supplier reference",
    childTableName: "ItemsWithoutReference",
    argument: "",
    rightCode: "",
    useKey: "",
    icon: {icon: 0xe6cc, color: "#FFEF6C00", size: 24}
  });

  return items;
}
```
