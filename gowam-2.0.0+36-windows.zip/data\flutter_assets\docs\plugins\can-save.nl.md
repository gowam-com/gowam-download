# Kan opslaan

Gowam roept uw functie aan wanneer de gebruiker opslaat, voordat Gowam het formulier leest. Uw functie kan het opslaan weigeren.

Gowam roept Kan opslaan aan op twee pagina's:

- `Item`: wanneer de gebruiker een artikel opslaat.
- `Doc`: wanneer de gebruiker op **Opslaan** klikt om een document af te werken (een factuur, een bestelling, een levering). Gowam roept het niet aan wanneer Gowam een concept bewaart, bijvoorbeeld wanneer de gebruiker een regel opent, en ook niet voor een kasverrichting. `objectId` is `0` voor een nieuw document (een document dat nooit met **Opslaan** is opgeslagen).

De andere pagina's roepen Kan opslaan nooit aan. Klik op **Controleren** in de plugin om te zien of Gowam uw regel aanroept (zie [Een plugin controleren](index.md#een-plugin-controleren)).

## Registreren

```js
registerCanSave({page: "Item", function: "itemCanSave"});
```

| Parameter | |
|---|---|
| `page` | de naam van de pagina |
| `function` | de naam van uw functie |
| `active` | `false` zet de regel uit |

## Uw functie

```js
function itemCanSave(tableName, controls, objectId) {
  return "";
}
```

- `tableName`: de naam van de pagina.
- `controls`: de controls van het formulier.
- `objectId`: de id van het record, `0` voor een nieuw record.

Geef `""` terug om op te slaan. Geef een tekst terug om te weigeren: Gowam slaat niet op en toont de tekst aan de gebruiker.

Kan opslaan ziet het formulier. Om het record te controleren dat Gowam gaat schrijven, gebruikt u [Voor het opslaan](before-save.md).

## Voorbeeld 1: het artikel heeft een opmerking nodig

```js
registerCanSave({page: "Item", function: "itemNeedComment"});
```

```js
function itemNeedComment(tableName, controls, objectId) {
  if (Field.stringGet(controls, "@comment") === "") {
    return "Type a comment for the item";
  }

  return "";
}
```

## Voorbeeld 2: een nieuw artikel heeft een familie nodig

```js
registerCanSave({page: "Item", function: "itemNeedFamily"});
```

```js
function itemNeedFamily(tableName, controls, objectId) {
  if (objectId !== 0) {
    return "";
  }

  if (Field.lookupGet(controls, "@familyCode") === 0) {
    return "Choose a family for the new item";
  }

  return "";
}
```

## Voorbeeld 3: een leverancier heeft een leveranciersreferentie nodig

```js
registerCanSave({page: "Item", function: "itemNeedSupplierReference"});
```

```js
function itemNeedSupplierReference(tableName, controls, objectId) {
  var supplier = Field.lookupGet(controls, "@supplierThirdPartyId");
  var reference = Field.stringGet(controls, "@supplierReference");

  if (supplier !== 0 && reference === "") {
    return "Type the reference of the item at the supplier";
  }

  return "";
}
```

## Voorbeeld 4: het aantal artikelen beperken

De functie telt de artikelen in de database.

```js
registerCanSave({page: "Item", function: "itemLimit"});
```

```js
function itemLimit(tableName, controls, objectId) {
  if (objectId !== 0) {
    return "";
  }

  if (LDAO.countAllSync("Item") >= 5000) {
    return "You cannot have more than 5000 items";
  }

  return "";
}
```
