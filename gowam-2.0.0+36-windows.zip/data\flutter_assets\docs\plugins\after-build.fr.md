# Après construction du formulaire

Gowam appelle votre fonction quand un formulaire est prêt, juste avant d'afficher le formulaire. Votre fonction peut masquer, modifier, déplacer, supprimer ou ajouter des contrôles.

## Enregistrement

```js
registerAfterBuildUI({page: "Item", type: "form", function: "itemForm"});
```

| Paramètre | |
|---|---|
| `page` | le nom de la page (voir [Trouver les noms](index.md#trouver-les-noms-des-pages-et-des-champs)) |
| `type` | `"form"` (par défaut) : le formulaire. `"preview"` : l'aperçu à côté de la liste |
| `function` | le nom de votre fonction |
| `active` | `false` désactive la ligne |

Gowam garde une seule fonction par page et par type. Mettez toutes les modifications d'un formulaire dans une seule fonction.

## Votre fonction

```js
function itemForm(controls) {
  return controls;
}
```

Retournez la liste des contrôles, pas un texte JSON. Si votre fonction lève une erreur ou retourne une valeur incorrecte, Gowam affiche son propre formulaire.

Chaque contrôle que vous ajoutez a besoin d'un `fieldName` qu'aucun autre contrôle n'utilise.

Gowam n'enregistre pas la valeur d'un champ que vous ajoutez. Pour garder la valeur, enregistrez-la vous-même, par exemple dans [Avant l'enregistrement](before-save.md) ou dans un événement [Valider](validate.md) sur un bouton.

## Exemple 1 : masquer un champ et modifier un libellé

```js
registerAfterBuildUI({page: "Item", type: "form", function: "itemForm"});
```

```js
function itemForm(controls) {
  Field.setVisible(controls, "@comment", false);
  Field.setLabel(controls, "@supplierReference", "Supplier article");

  return controls;
}
```

## Exemple 2 : verrouiller le code d'un article existant

Le champ `id` contient l'id de l'article. Il est vide pour un nouvel article.

```js
registerAfterBuildUI({page: "Item", type: "form", function: "itemLockCode"});
```

```js
function itemLockCode(controls) {
  var id = Field.integerGet(controls, "id");

  if (id > 0) {
    Field.setReadOnly(controls, "@itemId", true);
  }

  return controls;
}
```

## Exemple 3 : ajouter un champ

La fonction ajoute un champ après le code : le code de remplacement de l'article.

```js
registerAfterBuildUI({page: "Item", type: "form", function: "itemAddReplacement"});
```

```js
function itemAddReplacement(controls) {
  var index = Field.getControlIndex(controls, "@itemId");

  if (index === null) {
    return controls;
  }

  var field = GenControl.textField({
    fieldName: "itemReplacement",
    label: "Replacement itemId",
    initialValue: ""
  });

  controls.splice(index + 1, 0, field);

  return controls;
}
```

## Exemple 4 : ajouter un bouton

La fonction ajoute un bouton avant le bouton **Enregistrer**. Un événement [Valider](validate.md) sur le nom de champ du bouton s'exécute quand l'utilisateur clique sur ce bouton. Ici, le bouton copie la référence fournisseur dans le commentaire.

```js
registerAfterBuildUI({page: "Item", type: "form", function: "itemAddCopyButton"});
registerValidate({page: "Item", field: "itemCopyButton", function: "itemCopyReference"});
```

```js
function itemAddCopyButton(controls) {
  var index = Field.getControlIndex(controls, "btnSave");
  var button = GenControl.buttonFunction({
    fieldName: "itemCopyButton",
    label: "Copy the supplier reference to the comment"
  });

  controls.splice(index, 0, button);

  return controls;
}

function itemCopyReference(controls, properties) {
  var reference = Field.stringGet(controls, "@supplierReference");

  if (reference === "") {
    return "There is no supplier reference";
  }

  Field.stringSet(controls, reference, "@comment");

  return Cmd.updatedMaps + JSON.stringify(controls);
}
```

## Exemple 5 : modifier l'aperçu

Avec `type: "preview"`, votre fonction modifie l'aperçu qui s'affiche à côté de la liste. Ici, elle ajoute le code de remplacement au-dessus de l'image de l'article. Dans l'aperçu, le code et l'image sont dans la carte `names` : la fonction modifie donc les contrôles de cette carte. L'image s'affiche quand l'utilisateur clique sur l'icône d'image à côté du code.

```js
registerAfterBuildUI({page: "Item", type: "preview", function: "itemPreview"});
```

```js
function itemPreview(controls) {
  var names = Field.getControl(controls, "names");

  if (names === null) {
    return controls;
  }

  var cardControls = names.genCard.columns[0].controls;
  var index = Field.getControlIndex(cardControls, "picture");

  if (index === null) {
    index = Field.getControlIndex(cardControls, "addPicture");
  }

  if (index === null) {
    return controls;
  }

  var field = GenControl.textField({
    fieldName: "itemReplacementPreview",
    label: "Replacement itemId",
    initialValue: ""
  });

  cardControls.splice(index, 0, field);

  return controls;
}
```

## Exemple 6 : un bouton Statistiques dans l'aperçu

Le bouton ouvre la page d'un plugin [Liste/Formulaire](list-form.md#exemple-2-les-ventes-dun-article) avec les ventes de l'article. `navigateToForm` ouvre cette page avec l'id de l'article.

```js
registerAfterBuildUI({page: "Item", type: "preview", function: "itemAddStatisticsButton"});
registerValidate({page: "Item", field: "itemStatisticsButton", function: "itemOpenSales"});
```

```js
function itemAddStatisticsButton(controls) {
  var index = Field.getControlIndex(controls, "names");

  if (index === null) {
    index = controls.length;
  }

  var button = GenControl.buttonFunction({
    fieldName: "itemStatisticsButton",
    label: "Statistics"
  });

  controls.splice(index, 0, button);

  return controls;
}

function itemOpenSales(controls, properties) {
  var objectId = JSON.parse(properties).objectId;

  navigateToForm(objectId, "ItemPluginStatistics", "", 0, "Sales history", "", null, null, false);

  return "";
}
```
