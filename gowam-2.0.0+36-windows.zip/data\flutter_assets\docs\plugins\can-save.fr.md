# Peut enregistrer

Gowam appelle votre fonction quand l'utilisateur enregistre, avant que Gowam lise le formulaire. Votre fonction peut refuser l'enregistrement.

Gowam appelle Peut enregistrer sur deux pages :

- `Item` : quand l'utilisateur enregistre un article.
- `Doc` : quand l'utilisateur clique sur **Enregistrer** pour terminer un document (une facture, une commande, une livraison). Gowam ne l'appelle pas quand il garde un brouillon, par exemple quand l'utilisateur ouvre une ligne, ni pour une opération de caisse. `objectId` vaut `0` pour un nouveau document (un document qui n'a jamais été enregistré avec **Enregistrer**).

Les autres pages n'appellent jamais Peut enregistrer. Pour voir si Gowam appelle votre ligne, cliquez sur **Contrôler** dans le plugin (voir [Contrôler un plugin](index.md#controler-un-plugin)).

## Enregistrement

```js
registerCanSave({page: "Item", function: "itemCanSave"});
```

| Paramètre | |
|---|---|
| `page` | le nom de la page |
| `function` | le nom de votre fonction |
| `active` | `false` désactive la ligne |

## Votre fonction

```js
function itemCanSave(tableName, controls, objectId) {
  return "";
}
```

- `tableName` : le nom de la page.
- `controls` : les contrôles du formulaire.
- `objectId` : l'id de l'enregistrement, `0` pour un nouvel enregistrement.

Retournez `""` pour enregistrer. Retournez un texte pour refuser : Gowam n'enregistre pas et affiche le texte à l'utilisateur.

Peut enregistrer voit le formulaire. Pour vérifier l'enregistrement que Gowam va écrire, utilisez [Avant l'enregistrement](before-save.md).

## Exemple 1 : l'article a besoin d'un commentaire

```js
registerCanSave({page: "Item", function: "itemNeedComment"});
```

```js
function itemNeedComment(tableName, controls, objectId) {
  if (Field.stringGet(controls, "@comment") === "") {
    return "Type a comment for the item";
  }

  return "";
}
```

## Exemple 2 : un nouvel article a besoin d'une famille

```js
registerCanSave({page: "Item", function: "itemNeedFamily"});
```

```js
function itemNeedFamily(tableName, controls, objectId) {
  if (objectId !== 0) {
    return "";
  }

  if (Field.lookupGet(controls, "@familyCode") === 0) {
    return "Choose a family for the new item";
  }

  return "";
}
```

## Exemple 3 : un fournisseur a besoin d'une référence fournisseur

```js
registerCanSave({page: "Item", function: "itemNeedSupplierReference"});
```

```js
function itemNeedSupplierReference(tableName, controls, objectId) {
  var supplier = Field.lookupGet(controls, "@supplierThirdPartyId");
  var reference = Field.stringGet(controls, "@supplierReference");

  if (supplier !== 0 && reference === "") {
    return "Type the reference of the item at the supplier";
  }

  return "";
}
```

## Exemple 4 : limiter le nombre d'articles

La fonction compte les articles dans la base de données.

```js
registerCanSave({page: "Item", function: "itemLimit"});
```

```js
function itemLimit(tableName, controls, objectId) {
  if (objectId !== 0) {
    return "";
  }

  if (LDAO.countAllSync("Item") >= 5000) {
    return "You cannot have more than 5000 items";
  }

  return "";
}
```
