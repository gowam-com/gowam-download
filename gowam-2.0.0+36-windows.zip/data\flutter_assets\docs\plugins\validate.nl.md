# Valideren

Gowam roept uw functie aan wanneer de gebruiker een veld wijzigt: wanneer de cursor een tekstveld verlaat, of wanneer de gebruiker een waarde kiest in een keuzelijst, een schakelaar of een selectievakje. Bij een knop roept Gowam uw functie aan wanneer de gebruiker op de knop klikt.

Op de knoppen van Gowam, Opslaan (`btnSave`), Verwijderen (`btnDelete`), Annuleren, Wijzigen, Toevoegen, Dupliceren en Selecteren, werkt uw functie vóór de actie van de knop, met of zonder `before: true`. Geef een tekst terug om de actie te stoppen: Gowam toont de tekst en slaat niet op, verwijdert niet en verlaat de pagina niet. Geef `""` terug en Gowam voert de actie uit. Gowam roept een plugin Valideren op Opslaan aan telkens wanneer de gebruiker opslaat: met de knop, de titelbalk of het toetsenbord. Die werkt vóór [Kan opslaan](can-save.md). Bij Opslaan gebruikt Gowam de tekst en `Cmd.updatedMaps`, maar geen ander commando.

De rijen van een document: wanneer de gebruiker een rij in het document wijzigt, horen de velden van de rij bij de pagina `Doc`, dus registreer de plugin Valideren op `page: "Doc"`. Een regel op `page: "DocRow"` werkt alleen in het rijformulier dat apart opent, vanuit het blad van een document. In de cellen van het blad roept Gowam Valideren niet aan.

Uw functie kan de waarde weigeren, de waarde wijzigen of andere velden van het formulier wijzigen.

## Registreren

```js
registerValidate({page: "Item", field: "@itemId", function: "itemCheckCode"});
```

| Parameter | |
|---|---|
| `page` | de naam van de pagina (zie [De namen vinden](index.md#de-namen-van-de-paginas-en-velden-vinden)) |
| `field` | de veldnaam |
| `function` | de naam van uw functie |
| `before` | `true`: uw functie werkt vóór de controle van Gowam. Standaard `false`: na de controle van Gowam |
| `active` | `false` zet de regel uit |

`type` heeft geen effect voor Valideren.

## Uw functie

```js
function itemCheckCode(controls, properties) {
  return "";
}
```

- `controls`: de controls van het formulier, met de nieuwe waarde.
- `properties`: een JSON-tekst, bijvoorbeeld `{"objectId": 12, "tableName": "Item", "fieldName": "@itemId"}`. Lees deze tekst met `JSON.parse(properties)`. `objectId` is `0` voor een nieuw record.

Teruggeven:

| Retourwaarde | Resultaat |
|---|---|
| `""` | geen fout |
| een tekst | Gowam toont deze fout aan de gebruiker. Bij een veld verschijnt de tekst bij het veld. Bij een knop verschijnt de tekst in een pop-upvenster |
| `Cmd.updatedMaps + JSON.stringify(controls)` | Gowam neemt uw controls over: waarden, labels, zichtbaar of niet. Voeg er een tekst achter toe om ook een fout te tonen |
| `Cmd.setFocus("@comment")` | de cursor gaat naar dit veld |

Met `before: false` doet Gowam eerst zijn eigen controle. Bij een tekstveld ziet de gebruiker het antwoord van uw functie.

Met `before: true` werkt uw functie eerst. Als uw functie een tekst teruggeeft, doet Gowam zijn eigen controle niet. Bij een knop die u toevoegt, vervangt uw functie de actie van de knop.

## Voorbeeld 1: een spatie of schuine streep in de code weigeren

Met `before: true` draait de functie vóór de controle van Gowam: als ze de code weigert, controleert Gowam de code niet.

```js
registerValidate({page: "Item", field: "@itemId", function: "itemCheckCode", before: true});
```

```js
function itemCheckCode(controls, properties) {
  var code = Field.stringGet(controls, "@itemId");

  if (code.indexOf(" ") >= 0 || code.indexOf("/") >= 0 || code.indexOf("\\") >= 0) {
    return "The code cannot contain a space, a slash (/) or a backslash (\\)";
  }

  return "";
}
```

## Voorbeeld 2: de naam met een hoofdletter laten beginnen

De functie wijzigt de waarde van het veld en geeft de controls terug.

```js
registerValidate({page: "Item", field: "@names[0", function: "itemCapitalName"});
```

```js
function itemCapitalName(controls, properties) {
  var name = Field.stringGet(controls, "@names[0");

  if (name === "") {
    return "";
  }

  var capitalName = name.charAt(0).toUpperCase() + name.substring(1);

  if (capitalName === name) {
    return "";
  }

  Field.stringSet(controls, capitalName, "@names[0");

  return Cmd.updatedMaps + JSON.stringify(controls);
}
```

## Voorbeeld 3: de verkoopprijs invullen vanuit de inkoopprijs

Wanneer de gebruiker een inkoopprijs typt en de verkoopprijs leeg is, zet de functie een verkoopprijs die 50 % hoger is.

```js
registerValidate({page: "Item", field: "-€purchasePrice", function: "itemFillSalePrice"});
```

```js
function itemFillSalePrice(controls, properties) {
  var purchasePrice = Field.floatGet(controls, "-€purchasePrice");
  var salePrice = Field.floatGet(controls, "-€salePrice");

  if (purchasePrice === 0 || salePrice !== 0) {
    return "";
  }

  Field.floatSet(controls, purchasePrice * 1.5, "-€salePrice");

  return Cmd.updatedMaps + JSON.stringify(controls);
}
```

## Voorbeeld 4: in de database controleren

De functie weigert een leveranciersreferentie die een ander artikel al gebruikt.

```js
registerValidate({page: "Item", field: "@supplierReference", function: "itemCheckSupplierReference"});
```

```js
function itemCheckSupplierReference(controls, properties) {
  var reference = Field.stringGet(controls, "@supplierReference");

  if (reference === "") {
    return "";
  }

  var objectId = JSON.parse(properties).objectId;
  var items = LDAO.getListFilterSync("Item", {filters: {supplierReference: reference}, count: 2});

  for (var i = 0; i < items.length; i++) {
    if (items[i]._id !== objectId) {
      return "Another item already uses this supplier reference";
    }
  }

  return "";
}
```

## Voorbeeld 5: iets doen wanneer de gebruiker op een knop klikt

Een plugin Valideren op een knop werkt wanneer de gebruiker op de knop klikt. Voeg de knop toe met [Na formulier opbouwen](after-build.md#voorbeeld-4-een-knop-toevoegen) en registreer daarna een plugin Valideren op de veldnaam van de knop.
