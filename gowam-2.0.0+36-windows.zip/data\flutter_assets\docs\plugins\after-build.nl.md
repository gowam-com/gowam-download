# Na formulier opbouwen

Gowam roept uw functie aan wanneer een formulier klaar is, net voordat Gowam het formulier toont. Uw functie kan controls verbergen, wijzigen, verplaatsen, verwijderen of toevoegen.

## Registreren

```js
registerAfterBuildUI({page: "Item", type: "form", function: "itemForm"});
```

| Parameter | |
|---|---|
| `page` | de naam van de pagina (zie [De namen vinden](index.md#de-namen-van-de-paginas-en-velden-vinden)) |
| `type` | `"form"` (standaard): het formulier. `"preview"`: de voorbeeldweergave naast de lijst |
| `function` | de naam van uw functie |
| `active` | `false` zet de regel uit |

Gowam bewaart één functie per pagina en type. Zet alle wijzigingen van een formulier in één functie.

## Uw functie

```js
function itemForm(controls) {
  return controls;
}
```

Geef de lijst van controls terug, geen JSON-tekst. Als uw functie een fout opwerpt of iets verkeerds teruggeeft, toont Gowam zijn eigen formulier.

Elke control die u toevoegt, heeft een `fieldName` nodig die geen andere control gebruikt.

Gowam slaat de waarde van een veld dat u toevoegt niet op. Om de waarde te bewaren, slaat u die zelf op, bijvoorbeeld in [Voor het opslaan](before-save.md) of in een plugin [Valideren](validate.md) van een knop.

## Voorbeeld 1: een veld verbergen en een label wijzigen

```js
registerAfterBuildUI({page: "Item", type: "form", function: "itemForm"});
```

```js
function itemForm(controls) {
  Field.setVisible(controls, "@comment", false);
  Field.setLabel(controls, "@supplierReference", "Supplier article");

  return controls;
}
```

## Voorbeeld 2: de code van een bestaand artikel vergrendelen

Het veld `id` bevat de id van het artikel. Het veld is leeg voor een nieuw artikel.

```js
registerAfterBuildUI({page: "Item", type: "form", function: "itemLockCode"});
```

```js
function itemLockCode(controls) {
  var id = Field.integerGet(controls, "id");

  if (id > 0) {
    Field.setReadOnly(controls, "@itemId", true);
  }

  return controls;
}
```

## Voorbeeld 3: een veld toevoegen

De functie voegt een veld toe na de code: de vervangcode van het artikel.

```js
registerAfterBuildUI({page: "Item", type: "form", function: "itemAddReplacement"});
```

```js
function itemAddReplacement(controls) {
  var index = Field.getControlIndex(controls, "@itemId");

  if (index === null) {
    return controls;
  }

  var field = GenControl.textField({
    fieldName: "itemReplacement",
    label: "Replacement itemId",
    initialValue: ""
  });

  controls.splice(index + 1, 0, field);

  return controls;
}
```

## Voorbeeld 4: een knop toevoegen

De functie voegt een knop toe vóór de knop **Opslaan**. Een plugin [Valideren](validate.md) op de veldnaam van de knop werkt wanneer de gebruiker op de knop klikt. Hier kopieert de knop de leveranciersreferentie naar de opmerking.

```js
registerAfterBuildUI({page: "Item", type: "form", function: "itemAddCopyButton"});
registerValidate({page: "Item", field: "itemCopyButton", function: "itemCopyReference"});
```

```js
function itemAddCopyButton(controls) {
  var index = Field.getControlIndex(controls, "btnSave");
  var button = GenControl.buttonFunction({
    fieldName: "itemCopyButton",
    label: "Copy the supplier reference to the comment"
  });

  controls.splice(index, 0, button);

  return controls;
}

function itemCopyReference(controls, properties) {
  var reference = Field.stringGet(controls, "@supplierReference");

  if (reference === "") {
    return "There is no supplier reference";
  }

  Field.stringSet(controls, reference, "@comment");

  return Cmd.updatedMaps + JSON.stringify(controls);
}
```

## Voorbeeld 5: de voorbeeldweergave wijzigen

Met `type: "preview"` wijzigt uw functie de voorbeeldweergave die naast de lijst verschijnt. Hier voegt de functie de vervangcode toe boven de afbeelding van het artikel. In de voorbeeldweergave staan de code en de afbeelding in de kaart `names`, dus wijzigt de functie de controls van die kaart. De afbeelding verschijnt als de gebruiker op het afbeeldingspictogram naast de code klikt.

```js
registerAfterBuildUI({page: "Item", type: "preview", function: "itemPreview"});
```

```js
function itemPreview(controls) {
  var names = Field.getControl(controls, "names");

  if (names === null) {
    return controls;
  }

  var cardControls = names.genCard.columns[0].controls;
  var index = Field.getControlIndex(cardControls, "picture");

  if (index === null) {
    index = Field.getControlIndex(cardControls, "addPicture");
  }

  if (index === null) {
    return controls;
  }

  var field = GenControl.textField({
    fieldName: "itemReplacementPreview",
    label: "Replacement itemId",
    initialValue: ""
  });

  cardControls.splice(index, 0, field);

  return controls;
}
```

## Voorbeeld 6: een knop Statistieken in de voorbeeldweergave

De knop opent de pagina van een [Lijst/Formulier](list-form.md#voorbeeld-2-de-verkopen-van-een-artikel)-plugin met de verkopen van het artikel. `navigateToForm` opent deze pagina met het id van het artikel.

```js
registerAfterBuildUI({page: "Item", type: "preview", function: "itemAddStatisticsButton"});
registerValidate({page: "Item", field: "itemStatisticsButton", function: "itemOpenSales"});
```

```js
function itemAddStatisticsButton(controls) {
  var index = Field.getControlIndex(controls, "names");

  if (index === null) {
    index = controls.length;
  }

  var button = GenControl.buttonFunction({
    fieldName: "itemStatisticsButton",
    label: "Statistics"
  });

  controls.splice(index, 0, button);

  return controls;
}

function itemOpenSales(controls, properties) {
  var objectId = JSON.parse(properties).objectId;

  navigateToForm(objectId, "ItemPluginStatistics", "", 0, "Sales history", "", null, null, false);

  return "";
}
```
