# Lijst/Formulier

Een plugin Lijst/Formulier voegt een volledige pagina toe aan Gowam: een lijst van kaarten en een formulier, zoals de pagina's van Gowam. Gowam roept de methoden aan van een object dat uw code definieert.

## Registreren

```js
registerListForm({page: "ItemsWithoutReference", class: "ItemsWithoutReference", listSearch: true, listPreview: false, listAdd: false, listForm: true, listMaxWidth: 1200, formDelete: false, formSave: true, formMaxWidth: 800, listCardsCount: 20});
```

| Parameter | |
|---|---|
| `page` | de naam van uw pagina. Gebruik een naam die Gowam niet gebruikt |
| `class` | de naam van het object in uw code |
| `listSearch` | een zoekvak boven de lijst tonen |
| `listPreview` | een voorbeeldweergave tonen wanneer de gebruiker op een kaart klikt. Met `false` opent de klik het formulier |
| `listAdd` | de knop tonen die een record toevoegt |
| `listForm` | de lijst heeft een formulier |
| `listMaxWidth`, `formMaxWidth` | de maximale breedte van de lijst en van het formulier, in pixels |
| `formDelete`, `formSave` | de knoppen voor verwijderen en opslaan tonen in de titelbalk van het formulier |
| `listCardsCount` | het aantal kaarten dat Gowam elke keer vraagt |
| `backgroundColors` | de kleuren van de achtergrond, bijvoorbeeld `["#ffffff", "#f5f5f5", "#e3f2fd"]` |
| `active` | `false` zet de regel uit |

Om de pagina te openen, voegt u een menu-item toe aan een menu met een plugin [Menu-item](menu-item.md#voorbeeld-4-uw-eigen-pagina-openen): `type: "list"` en `childTableName` = de naam van uw pagina.

## De methoden

Definieer alle methoden, ook de methoden die u niet nodig hebt. Een methode kan `async` zijn.

| Methode | Retourwaarde |
|---|---|
| `genListGetTitle(parentId, parentTableName, args)` | de titel van de lijst |
| `genListFirstControls(parentId, parentTableName, args)` | de controls boven de lijst, `[]` voor geen controls |
| `genListGetCards(filter, offset, count, parentId, parentTableName, controls, args)` | de kaarten: `count` kaarten vanaf kaartnummer `offset`. `filter` is de tekst van het zoekvak. `LDAO.getListFilterSync` zoekt deze tekst in de velden van `listSearchProperties` |
| `genListGetCard(objectId, parentTableName, parentId, controls, args)` | de kaart van één record |
| `genListNavigateBack(controls)` | `""` |
| `genPreviewGetControls(objectId, isSelect, args)` | de controls van de voorbeeldweergave, `[]` voor geen controls |
| `genGetDropdownDisplay(id, args)` | de tekst die een keuzelijst voor dit record toont |
| `genGetSearchCode(id, args)` | de code van het record |
| `genFormGetTitle(objectId, parentId, parentTableName, subForm, args)` | de titel van het formulier |
| `genFormGetControls(objectId, parentId, parentTableName, subForm, source, searchControls, args)` | de controls van het formulier |
| `genFormSave(controls, objectId, parentId, parentTableName, fromSaveButton, subForm, args)` | de id van het opgeslagen record, `0` als het record niet is opgeslagen |
| `genFormDelete(objectId, args)` | de id van het verwijderde record, `0` als het record niet is verwijderd |
| `genFormNavigateBack(controls, objectId)` | `""` |

Geef lijsten en objecten terug, geen JSON-teksten. `args` is een JSON-tekst, of `""`.

Een kaart is een object met de id van het record en kolommen met controls:

```js
{
  objectId: 12,
  columns: [
    {width: 100, widthType: "variablePercentage", controls: [GenControl.text({fieldName: "title", label: "COFFEE"})]}
  ]
}
```

`widthType` is `"variablePercentage"` (de breedte is een percentage) of `"fixedPixels"` (de breedte is in pixels).

## Voorbeeld 1: de artikelen zonder leveranciersreferentie

De pagina toont de artikelen die geen leveranciersreferentie hebben. Een klik op een artikel opent een formulier waarin de gebruiker de referentie typt.

```js
registerListForm({page: "ItemsWithoutReference", class: "ItemsWithoutReference", listSearch: true, listPreview: false, listAdd: false, listForm: true, listMaxWidth: 1200, formDelete: false, formSave: true, formMaxWidth: 800, listCardsCount: 20});
```

De functie `itemFieldName` geeft de naam van een veld in een Gowam-database of in een logistieke database (zie [Records](index.md#records)).

```js
function itemFieldName(record, gowamName, logisticsName) {
  if (record.uuid === undefined) {
    return gowamName;
  }

  return logisticsName;
}

function itemTitle(item) {
  var code = item[itemFieldName(item, "itemId", "artid")];
  var names = item.names || [];

  return code + " " + (names[0] || "");
}

function itemCard(item) {
  return {
    objectId: item._id,
    columns: [
      {
        width: 100,
        widthType: "variablePercentage",
        controls: [
          GenControl.text({fieldName: "title", label: itemTitle(item), textStyle: {fontWeight: "bold", fontSize: 16}})
        ]
      }
    ]
  };
}

var ItemsWithoutReference = {
  genListGetTitle: function (parentId, parentTableName, args) {
    return "Items without a supplier reference";
  },

  genListFirstControls: function (parentId, parentTableName, args) {
    return [];
  },

  genListGetCards: function (filter, offset, count, parentId, parentTableName, controls, args) {
    var items = LDAO.getListFilterSync("Item", {
      search: filter,
      listSearchProperties: ["itemId", "names"],
      filters: {supplierReference: ""},
      offset: offset,
      count: count
    });

    return items.map(itemCard);
  },

  genListGetCard: function (objectId, parentTableName, parentId, controls, args) {
    return itemCard(LDAO.getSync("Item", objectId));
  },

  genListNavigateBack: function (controls) {
    return "";
  },

  genPreviewGetControls: function (objectId, isSelect, args) {
    return [];
  },

  genGetDropdownDisplay: function (id, args) {
    return itemTitle(LDAO.getSync("Item", id));
  },

  genGetSearchCode: function (id, args) {
    var item = LDAO.getSync("Item", id);

    return item[itemFieldName(item, "itemId", "artid")];
  },

  genFormGetTitle: function (objectId, parentId, parentTableName, subForm, args) {
    return "Supplier reference";
  },

  genFormGetControls: function (objectId, parentId, parentTableName, subForm, source, searchControls, args) {
    var item = LDAO.getSync("Item", objectId);

    return [
      GenControl.text({fieldName: "itemTitleText", label: itemTitle(item), textStyle: {fontWeight: "bold", fontSize: 16}}),
      Field.stringControl({fieldName: "itemReference", label: "Supplier reference", text: "", maxLength: 30}),
      GenControl.buttonSave()
    ];
  },

  genFormSave: async function (controls, objectId, parentId, parentTableName, fromSaveButton, subForm, args) {
    var reference = Field.stringGet(controls, "itemReference");

    if (reference === "") {
      return 0;
    }

    var item = LDAO.getSync("Item", objectId);

    item[itemFieldName(item, "supplierReference", "buyartid")] = reference;
    await LDAO.save("Item", item);

    return objectId;
  },

  genFormDelete: function (objectId, args) {
    return 0;
  },

  genFormNavigateBack: function (controls, objectId) {
    return "";
  }
};
```

## Voorbeeld 2: de verkopen van een artikel

De pagina toont de verkoopgeschiedenis van één artikel: de documentregels in een tabel, met de marge. Ze heeft geen lijst: de knop **Statistics** van [Na formulier opbouwen](after-build.md#voorbeeld-6-een-knop-statistieken-in-de-voorbeeldweergave) opent haar formulier met het id van het artikel. De functies `itemFieldName` en `itemTitle` van voorbeeld 1 moeten ook in uw code staan.

```js
registerListForm({page: "ItemPluginStatistics", class: "ItemPluginStatistics", listSearch: false, listPreview: false, listAdd: false, listForm: true, formDelete: false, formSave: false});
```

```js
function itemSalesRow(row) {
  var amount = row.amount || 0;
  var costAmount = row[itemFieldName(row, "costAmount", "costamount")] || 0;

  return [
    row[itemFieldName(row, "journalId", "jnl")] || "",
    String(row.number || ""),
    String(row.date || "").substring(0, 10),
    row.qty || 0,
    row[itemFieldName(row, "unitPrice", "unitprice")] || 0,
    row[itemFieldName(row, "discountPc", "discount")] || 0,
    amount,
    costAmount,
    amount - costAmount
  ];
}

var ItemPluginStatistics = {
  genListGetTitle: function (parentId, parentTableName, args) {
    return "Sales history";
  },

  genListFirstControls: function (parentId, parentTableName, args) {
    return [];
  },

  genListGetCards: function (filter, offset, count, parentId, parentTableName, controls, args) {
    return [];
  },

  genListGetCard: function (objectId, parentTableName, parentId, controls, args) {
    return {};
  },

  genListNavigateBack: function (controls) {
    return "";
  },

  genPreviewGetControls: function (objectId, isSelect, args) {
    return [];
  },

  genGetDropdownDisplay: function (id, args) {
    return "";
  },

  genGetSearchCode: function (id, args) {
    return "";
  },

  genFormGetTitle: function (objectId, parentId, parentTableName, subForm, args) {
    return "Sales history";
  },

  genFormGetControls: function (objectId, parentId, parentTableName, subForm, source, searchControls, args) {
    var item = LDAO.getSync("Item", objectId);
    var rows = getDocRowsByItemId(item[itemFieldName(item, "itemId", "artid")]);
    var controls = [GenControl.text({fieldName: "itemSalesTitle", label: itemTitle(item), textStyle: {fontWeight: "bold", fontSize: 16}})];

    if (rows.length === 0) {
      controls.push(GenControl.text({fieldName: "itemSalesNone", label: "No history found for this item."}));

      return controls;
    }

    controls.push(GenControl.text({fieldName: "itemSalesCount", label: "History (" + rows.length + " records)"}));
    controls.push(GenControl.gowamSheetViewer({
      fieldName: "itemSalesSheet",
      gowamSheet: {
        titles: ["Journal", "Number", "Date", "Quantity", "Unit price", "Discount", "Amount", "Cost amount", "Margin"],
        types: ["String", "String", "String", "double", "double", "double", "double", "double", "double"],
        data: rows.map(itemSalesRow)
      }
    }));

    return controls;
  },

  genFormSave: function (controls, objectId, parentId, parentTableName, fromSaveButton, subForm, args) {
    return 0;
  },

  genFormDelete: function (objectId, args) {
    return 0;
  },

  genFormNavigateBack: function (controls, objectId) {
    return "";
  }
};
```
