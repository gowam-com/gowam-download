# Élément de menu

Gowam appelle votre fonction quand il ouvre une page de menu, par exemple **Paramètres**, **Outils** ou **Autres fichiers**. Votre fonction peut ajouter, supprimer, renommer ou déplacer les entrées du menu.

Le menu latéral de Gowam n'appelle pas les plugins.

## Enregistrement

```js
registerBuildMenu({menu: "main_other_files", function: "itemOtherFilesMenu"});
```

| Paramètre | |
|---|---|
| `menu` | le nom du menu |
| `function` | le nom de votre fonction |
| `active` | `false` désactive la ligne |

Pour trouver le nom d'un menu, ouvrez le menu avec le **Mode développeur** activé et placez la souris sur l'icône de développeur de la barre de titre. Quelques noms :

| Menu | Nom |
|---|---|
| Actions | `main_action` |
| Autres fichiers | `main_other_files` |
| Processus | `main_process` |
| Rapport | `main_reports` |
| Outils | `main_tools` |
| Paramètres | `main_settings` |
| Paramètres / Options | `settings_options` |
| Paramètres / Articles | `settings_item_settings` |

## Votre fonction

```js
function itemOtherFilesMenu(items) {
  return items;
}
```

`items` est la liste des entrées du menu. Retournez la liste, pas un texte JSON. Chaque entrée est un objet :

```js
{
  key: "of_lookup_UNIT",
  type: "list",
  title: "Unit of measure",
  childTableName: "UNIT",
  argument: "",
  rightCode: "",
  useKey: "",
  isLight: false,
  icon: {icon: 0xf065b, color: "#FF455A64", size: 24}
}
```

| Champ | |
|---|---|
| `key` | un nom qu'aucune autre entrée n'utilise |
| `type` | `"list"` ouvre la liste de la page `childTableName`, `"form"` ouvre son formulaire, `"menu"` ouvre le menu `childTableName`, `"separator"` est une ligne |
| `title` | le texte de l'entrée |
| `childTableName` | le nom de la page ou du menu |
| `argument`, `rightCode`, `useKey` | gardez `""` pour vos entrées |
| `icon` | le code d'une [icône Flutter Material](https://api.flutter.dev/flutter/material/Icons-class.html) (le nombre dans `IconData(0xe34a, ...)`) et sa couleur au format `#AARRGGBB`, ou `{}` pour aucune icône |

Une nouvelle entrée a besoin de tous les champs texte : `title`, `childTableName`, `argument`, `rightCode` et `useKey`. S'il en manque un, Gowam n'utilise pas les modifications de votre fonction.

Les entrées de type `"function"` sont les entrées de Gowam. Vous pouvez les déplacer, les renommer ou les supprimer. Vous ne pouvez pas en créer une nouvelle.

## Exemple 1 : ajouter une entrée

La fonction ajoute une entrée à la fin du menu **Autres fichiers**. L'entrée ouvre la liste des articles.

```js
registerBuildMenu({menu: "main_other_files", function: "itemOtherFilesMenu"});
```

```js
function itemOtherFilesMenu(items) {
  items.push({
    key: "item_list",
    type: "list",
    title: "Items",
    childTableName: "Item",
    argument: "",
    rightCode: "",
    useKey: "",
    icon: {icon: 0xe34a, color: "#FF1565C0", size: 24}
  });

  return items;
}
```

## Exemple 2 : supprimer une entrée

```js
registerBuildMenu({menu: "main_other_files", function: "itemHideFamily"});
```

```js
function itemHideFamily(items) {
  return items.filter(function (item) {
    return item.key !== "of_lookup_ARTFAMILY";
  });
}
```

## Exemple 3 : renommer une entrée et la mettre en premier

```js
registerBuildMenu({menu: "main_other_files", function: "itemUnitsFirst"});
```

```js
function itemUnitsFirst(items) {
  for (var i = 0; i < items.length; i++) {
    if (items[i].key === "of_lookup_UNIT") {
      var unit = items.splice(i, 1)[0];

      unit.title = "Units";
      items.unshift(unit);

      return items;
    }
  }

  return items;
}
```

## Exemple 4 : ouvrir votre propre page

Un séparateur et une entrée qui ouvre la page d'un plugin [Liste/Formulaire](list-form.md).

```js
registerBuildMenu({menu: "main_other_files", function: "itemAddReferencePage"});
```

```js
function itemAddReferencePage(items) {
  items.push({
    key: "itemSeparator",
    type: "separator",
    title: "",
    childTableName: "",
    argument: "",
    rightCode: "",
    useKey: ""
  });

  items.push({
    key: "itemsWithoutReference",
    type: "list",
    title: "Items without a supplier reference",
    childTableName: "ItemsWithoutReference",
    argument: "",
    rightCode: "",
    useKey: "",
    icon: {icon: 0xe6cc, color: "#FFEF6C00", size: 24}
  });

  return items;
}
```
