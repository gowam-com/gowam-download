# Valider

Gowam appelle votre fonction quand l'utilisateur modifie un champ : quand le curseur quitte un champ texte, ou quand l'utilisateur sélectionne une valeur dans une liste déroulante, un interrupteur ou une case à cocher. Sur un bouton, Gowam appelle votre fonction quand l'utilisateur clique sur le bouton.

Sur les boutons de Gowam, Enregistrer (`btnSave`), Supprimer (`btnDelete`), Annuler, Modifier, Ajouter, Dupliquer et Sélectionner, votre fonction s'exécute avant l'action du bouton, avec ou sans `before: true`. Retournez un texte pour arrêter l'action : Gowam affiche le texte et n'enregistre pas, ne supprime pas et ne quitte pas. Retournez `""` et Gowam fait l'action. Gowam appelle un événement Valider sur Enregistrer chaque fois que l'utilisateur enregistre : avec le bouton, la barre de titre ou le clavier. Il s'exécute avant [Peut enregistrer](can-save.md). Sur Enregistrer, Gowam utilise le texte et `Cmd.updatedMaps`, mais aucune autre commande.

Les lignes d'un document : quand l'utilisateur modifie une ligne dans le document, les champs de la ligne appartiennent à la page `Doc`, donc enregistrez l'événement Valider sur `page: "Doc"`. Une ligne sur `page: "DocRow"` s'exécute seulement dans le formulaire de ligne qui s'ouvre seul, depuis la feuille d'un document. Dans les cellules de la feuille, Gowam n'appelle pas Valider.

Votre fonction peut refuser la valeur, modifier la valeur ou modifier d'autres champs du formulaire.

## Enregistrement

```js
registerValidate({page: "Item", field: "@itemId", function: "itemCheckCode"});
```

| Paramètre | |
|---|---|
| `page` | le nom de la page (voir [Trouver les noms](index.md#trouver-les-noms-des-pages-et-des-champs)) |
| `field` | le nom du champ |
| `function` | le nom de votre fonction |
| `before` | `true` : votre fonction s'exécute avant la vérification de Gowam. Par défaut `false` : après la vérification de Gowam |
| `active` | `false` désactive la ligne |

`type` n'a aucun effet pour Valider.

## Votre fonction

```js
function itemCheckCode(controls, properties) {
  return "";
}
```

- `controls` : les contrôles du formulaire, avec la nouvelle valeur.
- `properties` : un texte JSON, par exemple `{"objectId": 12, "tableName": "Item", "fieldName": "@itemId"}`. Lisez-le avec `JSON.parse(properties)`. `objectId` vaut `0` pour un nouvel enregistrement.

Retour :

| Retour | Résultat |
|---|---|
| `""` | pas d'erreur |
| un texte | Gowam affiche cette erreur à l'utilisateur. Pour un champ, le texte s'affiche avec le champ. Pour un bouton, il s'affiche dans une fenêtre popup |
| `Cmd.updatedMaps + JSON.stringify(controls)` | Gowam prend vos contrôles : valeurs, libellés, visibles ou non. Ajoutez un texte après pour afficher aussi une erreur |
| `Cmd.setFocus("@comment")` | le curseur va dans ce champ |

Avec `before: false`, Gowam fait d'abord sa propre vérification. Sur un champ texte, l'utilisateur voit la réponse de votre fonction.

Avec `before: true`, votre fonction s'exécute en premier. Si elle retourne un texte, Gowam ne fait pas sa propre vérification. Sur un bouton que vous ajoutez, votre fonction remplace l'action du bouton.

## Exemple 1 : refuser un espace ou une barre oblique dans le code

Avec `before: true`, la fonction s'exécute avant la vérification de Gowam : quand elle refuse le code, Gowam ne le vérifie pas.

```js
registerValidate({page: "Item", field: "@itemId", function: "itemCheckCode", before: true});
```

```js
function itemCheckCode(controls, properties) {
  var code = Field.stringGet(controls, "@itemId");

  if (code.indexOf(" ") >= 0 || code.indexOf("/") >= 0 || code.indexOf("\\") >= 0) {
    return "The code cannot contain a space, a slash (/) or a backslash (\\)";
  }

  return "";
}
```

## Exemple 2 : commencer le nom par une majuscule

La fonction modifie la valeur du champ et retourne les contrôles.

```js
registerValidate({page: "Item", field: "@names[0", function: "itemCapitalName"});
```

```js
function itemCapitalName(controls, properties) {
  var name = Field.stringGet(controls, "@names[0");

  if (name === "") {
    return "";
  }

  var capitalName = name.charAt(0).toUpperCase() + name.substring(1);

  if (capitalName === name) {
    return "";
  }

  Field.stringSet(controls, capitalName, "@names[0");

  return Cmd.updatedMaps + JSON.stringify(controls);
}
```

## Exemple 3 : remplir le prix de vente à partir du prix d'achat

Quand l'utilisateur tape un prix d'achat et que le prix de vente est vide, la fonction met un prix de vente 50 % plus élevé.

```js
registerValidate({page: "Item", field: "-€purchasePrice", function: "itemFillSalePrice"});
```

```js
function itemFillSalePrice(controls, properties) {
  var purchasePrice = Field.floatGet(controls, "-€purchasePrice");
  var salePrice = Field.floatGet(controls, "-€salePrice");

  if (purchasePrice === 0 || salePrice !== 0) {
    return "";
  }

  Field.floatSet(controls, purchasePrice * 1.5, "-€salePrice");

  return Cmd.updatedMaps + JSON.stringify(controls);
}
```

## Exemple 4 : vérifier dans la base de données

La fonction refuse une référence fournisseur qu'un autre article utilise déjà.

```js
registerValidate({page: "Item", field: "@supplierReference", function: "itemCheckSupplierReference"});
```

```js
function itemCheckSupplierReference(controls, properties) {
  var reference = Field.stringGet(controls, "@supplierReference");

  if (reference === "") {
    return "";
  }

  var objectId = JSON.parse(properties).objectId;
  var items = LDAO.getListFilterSync("Item", {filters: {supplierReference: reference}, count: 2});

  for (var i = 0; i < items.length; i++) {
    if (items[i]._id !== objectId) {
      return "Another item already uses this supplier reference";
    }
  }

  return "";
}
```

## Exemple 5 : faire quelque chose quand l'utilisateur clique sur un bouton

Un événement Valider sur un bouton s'exécute quand l'utilisateur clique sur ce bouton. Ajoutez le bouton avec [Après construction du formulaire](after-build.md#exemple-4-ajouter-un-bouton), puis enregistrez un événement Valider sur son nom de champ.
