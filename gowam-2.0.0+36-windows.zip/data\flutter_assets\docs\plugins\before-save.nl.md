# Voor het opslaan

Gowam roept uw functie aan wanneer Gowam het record heeft gevuld met de waarden van het formulier, net voordat Gowam het record schrijft. Uw functie kan het record controleren en het opslaan weigeren.

Gowam roept Voor het opslaan aan op twee pagina's:

- `Item`: wanneer de gebruiker een artikel opslaat.
- `Doc`: wanneer de gebruiker op **Opslaan** klikt om een document af te werken, na de controles van Gowam. `object` is het document zonder zijn regels. Voor een nieuw document geeft Gowam het nummer, en de datum als die leeg is, na Voor het opslaan.

De andere pagina's roepen Voor het opslaan nooit aan. Klik op **Controleren** in de plugin om te zien of Gowam uw regel aanroept (zie [Een plugin controleren](index.md#een-plugin-controleren)).

## Registreren

```js
registerBeforeSave({page: "Item", function: "itemBeforeSave"});
```

| Parameter | |
|---|---|
| `page` | de naam van de pagina |
| `function` | de naam van uw functie |
| `active` | `false` zet de regel uit |

## Uw functie

```js
function itemBeforeSave(controls, tableName, object) {
  return "";
}
```

- `controls`: de controls van het formulier.
- `tableName`: de naam van de pagina.
- `object`: het record zoals Gowam het zal schrijven. De namen van de velden hangen af van de database (zie [Records](index.md#records)). Gowam laat de velden weg die leeg of `0` zijn.

Geef `""` terug om op te slaan. Geef een tekst terug om te weigeren: Gowam slaat niet op en toont de tekst aan de gebruiker.

Een wijziging van `object` heeft geen effect: Gowam schrijft zijn eigen record.

[Kan opslaan](can-save.md) werkt eerder en ziet alleen het formulier. Voor het opslaan ziet het record, met de waarden die Gowam heeft berekend.

## Voorbeeld 1: een verkoopprijs onder de inkoopprijs weigeren

```js
registerBeforeSave({page: "Item", function: "itemCheckMargin"});
```

```js
function itemCheckMargin(controls, tableName, object) {
  var salePrice = object.salePrice || object.saleprice || 0;
  var purchasePrice = object.purchasePrice || object.buyprice || 0;

  if (salePrice > 0 && salePrice < purchasePrice) {
    return "The sale price is lower than the purchase price";
  }

  return "";
}
```

## Voorbeeld 2: het artikel heeft een naam nodig

```js
registerBeforeSave({page: "Item", function: "itemNeedName"});
```

```js
function itemNeedName(controls, tableName, object) {
  var names = object.names || [];

  if (names.length === 0 || names[0].trim() === "") {
    return "Type a name for the item";
  }

  return "";
}
```

## Voorbeeld 3: elke opslag in de log schrijven

De functie weigert nooit. De functie schrijft een regel in het logbestand van Gowam (**Hulpmiddelen > Log > Logbestanden**).

```js
registerBeforeSave({page: "Item", function: "itemLogSave"});
```

```js
function itemLogSave(controls, tableName, object) {
  var code = object.itemId || object.artid;

  pluginPrint("Item saved: " + code);

  return "";
}
```
