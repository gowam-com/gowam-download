# Validate

Gowam calls your function when the user changes a field: when the cursor leaves a text field, or when the user selects a value in a dropdown, a switch or a check box. On a button, Gowam calls your function when the user clicks the button.

On the buttons of Gowam, Save (`btnSave`), Delete (`btnDelete`), Cancel, Edit, Add, Duplicate and Select, your function runs before the action of the button, with or without `before: true`. Return a text to stop the action: Gowam shows the text and does not save, delete or leave. Return `""` and Gowam does the action. Gowam calls a Validate on Save each time the user saves: with the button, the title bar or the keyboard. It runs before [Can Save](can-save.md). On Save, Gowam uses the text and `Cmd.updatedMaps`, but no other command.

The rows of a document: when the user changes a row inside the document, the row fields belong to the page `Doc`, so register the Validate on `page: "Doc"`. A line on `page: "DocRow"` runs only in the row form that opens alone, from the sheet of a document. In the cells of the sheet, Gowam does not call Validate.

Your function can refuse the value, change the value or change other fields of the form.

## Register

```js
registerValidate({page: "Item", field: "@itemId", function: "itemCheckCode"});
```

| Parameter | |
|---|---|
| `page` | the name of the page (see [Find the names](index.md#find-the-names-of-the-pages-and-fields)) |
| `field` | the field name |
| `function` | the name of your function |
| `before` | `true`: your function runs before the check of Gowam. Default `false`: after the check of Gowam |
| `active` | `false` switches the line off |

`type` has no effect for Validate.

## Your function

```js
function itemCheckCode(controls, properties) {
  return "";
}
```

- `controls`: the controls of the form, with the new value.
- `properties`: a JSON text, for example `{"objectId": 12, "tableName": "Item", "fieldName": "@itemId"}`. Read it with `JSON.parse(properties)`. `objectId` is `0` for a new record.

Return:

| Return | Result |
|---|---|
| `""` | no error |
| a text | Gowam shows this error to the user. For a field, the text shows with the field. For a button, it shows in a popup |
| `Cmd.updatedMaps + JSON.stringify(controls)` | Gowam takes your controls: values, labels, visible or not. Add a text after it to show an error too |
| `Cmd.setFocus("@comment")` | the cursor goes to this field |

With `before: false`, Gowam does its own check first. On a text field, the user sees the answer of your function.

With `before: true`, your function runs first. If it returns a text, Gowam does not do its own check. On a button that you add, your function replaces the action of the button.

## Example 1: refuse a space or a slash in the code

With `before: true`, the function runs before the check of Gowam: when it refuses the code, Gowam does not check it.

```js
registerValidate({page: "Item", field: "@itemId", function: "itemCheckCode", before: true});
```

```js
function itemCheckCode(controls, properties) {
  var code = Field.stringGet(controls, "@itemId");

  if (code.indexOf(" ") >= 0 || code.indexOf("/") >= 0 || code.indexOf("\\") >= 0) {
    return "The code cannot contain a space, a slash (/) or a backslash (\\)";
  }

  return "";
}
```

## Example 2: start the name with a capital letter

The function changes the value of the field and returns the controls.

```js
registerValidate({page: "Item", field: "@names[0", function: "itemCapitalName"});
```

```js
function itemCapitalName(controls, properties) {
  var name = Field.stringGet(controls, "@names[0");

  if (name === "") {
    return "";
  }

  var capitalName = name.charAt(0).toUpperCase() + name.substring(1);

  if (capitalName === name) {
    return "";
  }

  Field.stringSet(controls, capitalName, "@names[0");

  return Cmd.updatedMaps + JSON.stringify(controls);
}
```

## Example 3: fill the sale price from the purchase price

When the user types a purchase price and the sale price is empty, the function puts a sale price 50 % higher.

```js
registerValidate({page: "Item", field: "-€purchasePrice", function: "itemFillSalePrice"});
```

```js
function itemFillSalePrice(controls, properties) {
  var purchasePrice = Field.floatGet(controls, "-€purchasePrice");
  var salePrice = Field.floatGet(controls, "-€salePrice");

  if (purchasePrice === 0 || salePrice !== 0) {
    return "";
  }

  Field.floatSet(controls, purchasePrice * 1.5, "-€salePrice");

  return Cmd.updatedMaps + JSON.stringify(controls);
}
```

## Example 4: check in the database

The function refuses a supplier reference that another item already uses.

```js
registerValidate({page: "Item", field: "@supplierReference", function: "itemCheckSupplierReference"});
```

```js
function itemCheckSupplierReference(controls, properties) {
  var reference = Field.stringGet(controls, "@supplierReference");

  if (reference === "") {
    return "";
  }

  var objectId = JSON.parse(properties).objectId;
  var items = LDAO.getListFilterSync("Item", {filters: {supplierReference: reference}, count: 2});

  for (var i = 0; i < items.length; i++) {
    if (items[i]._id !== objectId) {
      return "Another item already uses this supplier reference";
    }
  }

  return "";
}
```

## Example 5: do something when the user clicks a button

A Validate on a button runs when the user clicks it. Add the button with [After Build](after-build.md#example-4-add-a-button), then register a Validate on its field name.
