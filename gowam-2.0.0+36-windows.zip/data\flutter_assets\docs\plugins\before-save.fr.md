# Avant l'enregistrement

Gowam appelle votre fonction quand il a rempli l'enregistrement avec les valeurs du formulaire, juste avant d'écrire l'enregistrement. Votre fonction peut vérifier l'enregistrement et refuser de l'enregistrer.

Gowam appelle Avant l'enregistrement sur deux pages :

- `Item` : quand l'utilisateur enregistre un article.
- `Doc` : quand l'utilisateur clique sur **Enregistrer** pour terminer un document, après les contrôles de Gowam. `object` est le document sans ses lignes. Pour un nouveau document, Gowam donne le numéro, et la date quand elle est vide, après Avant l'enregistrement.

Les autres pages n'appellent jamais Avant l'enregistrement. Pour voir si Gowam appelle votre ligne, cliquez sur **Contrôler** dans le plugin (voir [Contrôler un plugin](index.md#controler-un-plugin)).

## Enregistrement

```js
registerBeforeSave({page: "Item", function: "itemBeforeSave"});
```

| Paramètre | |
|---|---|
| `page` | le nom de la page |
| `function` | le nom de votre fonction |
| `active` | `false` désactive la ligne |

## Votre fonction

```js
function itemBeforeSave(controls, tableName, object) {
  return "";
}
```

- `controls` : les contrôles du formulaire.
- `tableName` : le nom de la page.
- `object` : l'enregistrement tel que Gowam va l'écrire. Les noms de ses champs dépendent de la base de données (voir [Enregistrements](index.md#enregistrements)). Gowam omet les champs qui sont vides ou à `0`.

Retournez `""` pour enregistrer. Retournez un texte pour refuser : Gowam n'enregistre pas et affiche le texte à l'utilisateur.

Une modification de `object` n'a aucun effet : Gowam écrit son propre enregistrement.

[Peut enregistrer](can-save.md) s'exécute plus tôt et ne voit que le formulaire. Avant l'enregistrement voit l'enregistrement, avec les valeurs que Gowam a calculées.

## Exemple 1 : refuser un prix de vente inférieur au prix d'achat

```js
registerBeforeSave({page: "Item", function: "itemCheckMargin"});
```

```js
function itemCheckMargin(controls, tableName, object) {
  var salePrice = object.salePrice || object.saleprice || 0;
  var purchasePrice = object.purchasePrice || object.buyprice || 0;

  if (salePrice > 0 && salePrice < purchasePrice) {
    return "The sale price is lower than the purchase price";
  }

  return "";
}
```

## Exemple 2 : l'article a besoin d'un nom

```js
registerBeforeSave({page: "Item", function: "itemNeedName"});
```

```js
function itemNeedName(controls, tableName, object) {
  var names = object.names || [];

  if (names.length === 0 || names[0].trim() === "") {
    return "Type a name for the item";
  }

  return "";
}
```

## Exemple 3 : écrire chaque enregistrement dans le log

La fonction ne refuse jamais. Elle écrit une ligne dans le fichier log de Gowam (**Outils > Log > Fichiers LOG**).

```js
registerBeforeSave({page: "Item", function: "itemLogSave"});
```

```js
function itemLogSave(controls, tableName, object) {
  var code = object.itemId || object.artid;

  pluginPrint("Item saved: " + code);

  return "";
}
```
