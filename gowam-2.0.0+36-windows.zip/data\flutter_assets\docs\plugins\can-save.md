# Can Save

Gowam calls your function when the user saves, before Gowam reads the form. Your function can refuse the save.

Gowam calls Can Save on two pages:

- `Item`: when the user saves an item.
- `Doc`: when the user clicks **Save** to finish a document (an invoice, an order, a delivery). Gowam does not call it when it keeps a draft, for example when the user opens a row, or for a cash drawer operation. `objectId` is `0` for a new document (a document that was never saved with **Save**).

The other pages never call Can Save. To see if Gowam calls your line, click **Check** in the plugin (see [Check a plugin](index.md#check-a-plugin)).

## Register

```js
registerCanSave({page: "Item", function: "itemCanSave"});
```

| Parameter | |
|---|---|
| `page` | the name of the page |
| `function` | the name of your function |
| `active` | `false` switches the line off |

## Your function

```js
function itemCanSave(tableName, controls, objectId) {
  return "";
}
```

- `tableName`: the name of the page.
- `controls`: the controls of the form.
- `objectId`: the id of the record, `0` for a new record.

Return `""` to save. Return a text to refuse: Gowam does not save and shows the text to the user.

Can Save sees the form. To check the record that Gowam is about to write, use [Before Save](before-save.md).

## Example 1: the item needs a comment

```js
registerCanSave({page: "Item", function: "itemNeedComment"});
```

```js
function itemNeedComment(tableName, controls, objectId) {
  if (Field.stringGet(controls, "@comment") === "") {
    return "Type a comment for the item";
  }

  return "";
}
```

## Example 2: a new item needs a family

```js
registerCanSave({page: "Item", function: "itemNeedFamily"});
```

```js
function itemNeedFamily(tableName, controls, objectId) {
  if (objectId !== 0) {
    return "";
  }

  if (Field.lookupGet(controls, "@familyCode") === 0) {
    return "Choose a family for the new item";
  }

  return "";
}
```

## Example 3: a supplier needs a supplier reference

```js
registerCanSave({page: "Item", function: "itemNeedSupplierReference"});
```

```js
function itemNeedSupplierReference(tableName, controls, objectId) {
  var supplier = Field.lookupGet(controls, "@supplierThirdPartyId");
  var reference = Field.stringGet(controls, "@supplierReference");

  if (supplier !== 0 && reference === "") {
    return "Type the reference of the item at the supplier";
  }

  return "";
}
```

## Example 4: limit the number of items

The function counts the items in the database.

```js
registerCanSave({page: "Item", function: "itemLimit"});
```

```js
function itemLimit(tableName, controls, objectId) {
  if (objectId !== 0) {
    return "";
  }

  if (LDAO.countAllSync("Item") >= 5000) {
    return "You cannot have more than 5000 items";
  }

  return "";
}
```
