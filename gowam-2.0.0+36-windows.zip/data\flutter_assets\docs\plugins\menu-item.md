# Menu Item

Gowam calls your function when it opens a menu page, for example **Settings**, **Tools** or **Other files**. Your function can add, remove, rename or move the entries of the menu.

The side menu of Gowam does not call plugins.

## Register

```js
registerBuildMenu({menu: "main_other_files", function: "itemOtherFilesMenu"});
```

| Parameter | |
|---|---|
| `menu` | the name of the menu |
| `function` | the name of your function |
| `active` | `false` switches the line off |

To find the name of a menu, open the menu with **Developer mode** on and put the mouse on the developer icon of the title bar. Some names:

| Menu | Name |
|---|---|
| Actions | `main_action` |
| Other files | `main_other_files` |
| Process | `main_process` |
| Report | `main_reports` |
| Tools | `main_tools` |
| Settings | `main_settings` |
| Settings / Options | `settings_options` |
| Settings / Items | `settings_item_settings` |

## Your function

```js
function itemOtherFilesMenu(items) {
  return items;
}
```

`items` is the list of the entries of the menu. Return the list, not a JSON text. Each entry is an object:

```js
{
  key: "of_lookup_UNIT",
  type: "list",
  title: "Unit of measure",
  childTableName: "UNIT",
  argument: "",
  rightCode: "",
  useKey: "",
  isLight: false,
  icon: {icon: 0xf065b, color: "#FF455A64", size: 24}
}
```

| Field | |
|---|---|
| `key` | a name that no other entry uses |
| `type` | `"list"` opens the list of the page `childTableName`, `"form"` opens its form, `"menu"` opens the menu `childTableName`, `"separator"` is a line |
| `title` | the text of the entry |
| `childTableName` | the name of the page or of the menu |
| `argument`, `rightCode`, `useKey` | keep `""` for your entries |
| `icon` | the code of a [Flutter Material icon](https://api.flutter.dev/flutter/material/Icons-class.html) (the number in `IconData(0xe34a, ...)`) and its color as `#AARRGGBB`, or `{}` for no icon |

A new entry needs all the text fields: `title`, `childTableName`, `argument`, `rightCode` and `useKey`. If one is missing, Gowam does not use the changes of your function.

The entries of type `"function"` are the entries of Gowam. You can move, rename or remove them. You cannot make a new one.

## Example 1: add an entry

The function adds an entry at the end of **Other files**. The entry opens the list of the items.

```js
registerBuildMenu({menu: "main_other_files", function: "itemOtherFilesMenu"});
```

```js
function itemOtherFilesMenu(items) {
  items.push({
    key: "item_list",
    type: "list",
    title: "Items",
    childTableName: "Item",
    argument: "",
    rightCode: "",
    useKey: "",
    icon: {icon: 0xe34a, color: "#FF1565C0", size: 24}
  });

  return items;
}
```

## Example 2: remove an entry

```js
registerBuildMenu({menu: "main_other_files", function: "itemHideFamily"});
```

```js
function itemHideFamily(items) {
  return items.filter(function (item) {
    return item.key !== "of_lookup_ARTFAMILY";
  });
}
```

## Example 3: rename an entry and put it first

```js
registerBuildMenu({menu: "main_other_files", function: "itemUnitsFirst"});
```

```js
function itemUnitsFirst(items) {
  for (var i = 0; i < items.length; i++) {
    if (items[i].key === "of_lookup_UNIT") {
      var unit = items.splice(i, 1)[0];

      unit.title = "Units";
      items.unshift(unit);

      return items;
    }
  }

  return items;
}
```

## Example 4: open your own page

A separator and an entry that opens the page of a [List/Form](list-form.md) plugin.

```js
registerBuildMenu({menu: "main_other_files", function: "itemAddReferencePage"});
```

```js
function itemAddReferencePage(items) {
  items.push({
    key: "itemSeparator",
    type: "separator",
    title: "",
    childTableName: "",
    argument: "",
    rightCode: "",
    useKey: ""
  });

  items.push({
    key: "itemsWithoutReference",
    type: "list",
    title: "Items without a supplier reference",
    childTableName: "ItemsWithoutReference",
    argument: "",
    rightCode: "",
    useKey: "",
    icon: {icon: 0xe6cc, color: "#FFEF6C00", size: 24}
  });

  return items;
}
```
