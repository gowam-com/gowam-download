# Function

Gowam calls a function with a fixed name at a fixed moment and uses the value that the function returns. Register the function with this name.

Today Gowam calls one function: `ItemPriceLDAO_getPrice`. It gives the price of an item when the user adds the item to a document (invoice, order, cash register).

## Register

```js
registerFunction({function: "ItemPriceLDAO_getPrice"});
```

| Parameter | |
|---|---|
| `function` | the name that Gowam calls |
| `active` | `false` switches the line off |

The name is fixed, so only one plugin can give it. If two plugins define the same function, Gowam uses the last one.

## Your function

```js
function ItemPriceLDAO_getPrice(args) {
  return null;
}
```

`args` is an object:

| Field | |
|---|---|
| `itemId` | the code of the item |
| `journalId` | the code of the journal of the document, `""` when there is no journal |
| `thirdPartyId` | the code of the customer or supplier, `""` when there is none |
| `sizeIndex` | the size of the item, `-1` when the item has no sizes |
| `date` | `null` today |
| `qty` | `1` today |

Return `{price: "12.50"}` to give the price. **The price must be a text**: use `price.toFixed(2)`. A number makes an error.

Return `null` to let Gowam calculate the price as usual.

Give the same kind of price as Gowam: the price with VAT for a journal with VAT included (such as the cash register), the price without VAT for the other journals.

## Example 1: a price for one item

```js
registerFunction({function: "ItemPriceLDAO_getPrice"});
```

```js
function ItemPriceLDAO_getPrice(args) {
  if (args.itemId === "BASKET") {
    return {price: "9.00"};
  }

  return null;
}
```

## Example 2: a price for one customer

```js
registerFunction({function: "ItemPriceLDAO_getPrice"});
```

```js
function ItemPriceLDAO_getPrice(args) {
  if (args.thirdPartyId === "C0001" && args.itemId === "COFFEE") {
    return {price: "2.50"};
  }

  return null;
}
```

## Example 3: a promotion between two dates

```js
registerFunction({function: "ItemPriceLDAO_getPrice"});
```

```js
function ItemPriceLDAO_getPrice(args) {
  var today = new Date().toISOString().substring(0, 10);

  if (args.itemId === "COFFEE" && today >= "2026-12-01" && today <= "2026-12-31") {
    return {price: "1.99"};
  }

  return null;
}
```

## Example 4: a staff price

In the journal `STAFF`, the price is the purchase price plus 10 %. The function reads the item in the database.

```js
registerFunction({function: "ItemPriceLDAO_getPrice"});
```

```js
function ItemPriceLDAO_getPrice(args) {
  if (args.journalId !== "STAFF") {
    return null;
  }

  var item = LDAO.getByKeySync("Item", args.itemId);

  if (item === null) {
    return null;
  }

  var purchasePrice = item.purchasePrice || item.buyprice || 0;

  if (purchasePrice === 0) {
    return null;
  }

  return {price: (purchasePrice * 1.1).toFixed(2)};
}
```

## Example 5: a price from a web service

The function asks your own web service for the price. The service answers with a JSON text such as `{"price": 2.5}`. If the service does not answer or does not know the item, Gowam calculates the price as usual. The header `Authorization` gives the key of your service.

```js
registerFunction({function: "ItemPriceLDAO_getPrice"});
```

```js
async function ItemPriceLDAO_getPrice(args) {
  var url = "https://prices.example.com/price?item=" + encodeURIComponent(args.itemId) + "&customer=" + encodeURIComponent(args.thirdPartyId);
  var answer = await httpRequest("GET", url, "", {"Authorization": "Bearer 1234567890"});

  if (answer.statusCode !== 200) {
    return null;
  }

  var price = JSON.parse(answer.body).price;

  if (typeof price !== "number") {
    return null;
  }

  return {price: price.toFixed(2)};
}
```
